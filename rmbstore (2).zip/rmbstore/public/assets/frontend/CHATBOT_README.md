# 🤖 RMB Store Chatbot Widget

A modern, responsive, and intelligent chatbot widget for your RMB Store frontend. This chatbot provides an engaging customer service experience with a beautiful UI and smart features.

## ✨ Features

### 🎨 **Modern Design**
- **Gradient Backgrounds** - Beautiful blue-to-purple gradients
- **Smooth Animations** - Slide-in, fade-in, and hover effects
- **Professional UI** - Clean, modern interface that matches your brand
- **Responsive Layout** - Works perfectly on all devices

### 🚀 **Smart Functionality**
- **Quick Reply Buttons** - Pre-defined responses for common questions
- **Typing Indicators** - Realistic chat experience with animated dots
- **Session Management** - Unique session IDs for each customer
- **Local Storage** - Chat history saved locally for better UX
- **Keyboard Shortcuts** - Quick access with Ctrl+K and Esc

### 📱 **Responsive Design**
- **Mobile-First** - Optimized for all screen sizes
- **Touch-Friendly** - Large buttons and touch targets
- **Adaptive Layout** - Automatically adjusts to device dimensions
- **Cross-Browser** - Works on all modern browsers

### 🔧 **Technical Features**
- **Vanilla JavaScript** - No external dependencies
- **Modular Code** - Easy to customize and extend
- **Performance Optimized** - Lightweight and fast
- **Accessibility** - Keyboard navigation and screen reader support

## 📁 File Structure

```
public/assets/frontend/
├── css/
│   └── chatbot.css          # Main stylesheet
├── js/
│   └── chatbot.js           # Core functionality
├── chatbot.html             # Standalone demo page
└── CHATBOT_README.md        # This documentation
```

## 🚀 Quick Start

### 1. **Test the Chatbot**
Open `chatbot.html` in your browser to see the chatbot in action:
```
http://localhost/rmbstore/public/assets/frontend/chatbot.html
```

### 2. **Integration Steps**
The chatbot is already integrated into your main layout files:
- ✅ `app/Views/layout/layout.php` (Admin dashboard)
- ✅ `app/Views/frontend/index.php` (Homepage)
- ✅ `app/Views/frontend/products.php` (Products page)
- ✅ `app/Views/frontend/category.php` (Category page)
- ✅ `app/Views/frontend/product-details.php` (Product details)

### 3. **CSS and JS Links**
The required CSS and JavaScript files are automatically included in your layout files.

## 🎯 Usage

### **For Customers:**
1. **Click the chat button** (bottom-right corner)
2. **Type your message** or use quick reply buttons
3. **Get instant responses** from the AI assistant
4. **Close/minimize** the chat as needed

### **Keyboard Shortcuts:**
- `Ctrl + K` - Open/Close chat
- `Esc` - Close chat
- `Enter` - Send message
- `Shift + Enter` - New line (if needed)

### **Quick Reply Buttons:**
- **Products** - Information about your product catalog
- **Support** - How to contact customer support
- **Hours** - Business hours and availability

## 🎨 Customization

### **Colors and Styling**
Edit `chatbot.css` to customize:
```css
/* Primary colors */
.chat-button {
    background: linear-gradient(135deg, #YOUR_COLOR1 0%, #YOUR_COLOR2 100%);
}

/* Chat window dimensions */
.chat-window {
    width: 400px;  /* Change width */
    height: 600px; /* Change height */
}
```

### **Positioning**
Adjust the chatbot position in `chatbot.css`:
```css
.chatbot-widget {
    bottom: 30px;  /* Distance from bottom */
    right: 30px;   /* Distance from right */
}
```

### **Responsive Breakpoints**
Customize mobile behavior:
```css
@media (max-width: 768px) {
    .chat-window {
        width: 320px;
        height: 450px;
    }
}
```

### **Messages and Responses**
Modify responses in `chatbot.js`:
```javascript
generateResponse(userMessage) {
    const message = userMessage.toLowerCase();
    
    // Add your custom responses here
    if (message.includes('your_keyword')) {
        return "Your custom response here!";
    }
    
    // ... existing code
}
```

## 🔧 Advanced Features

### **Database Integration**
The chatbot is ready for database integration. You can:
1. **Connect to your products table** for inventory queries
2. **Save conversations** to track customer interactions
3. **Implement real AI** using external APIs

### **Admin Panel Integration**
Add chatbot management to your admin panel:
- View all conversations
- Export chat histories
- Monitor customer interactions
- Set up automated responses

### **Analytics and Tracking**
Track chatbot performance:
- Conversation counts
- Popular questions
- Customer satisfaction
- Response effectiveness

## 📱 Browser Support

- ✅ **Chrome** 60+
- ✅ **Firefox** 55+
- ✅ **Safari** 12+
- ✅ **Edge** 79+
- ✅ **Mobile browsers** (iOS Safari, Chrome Mobile)

## 🚨 Troubleshooting

### **Chatbot Not Appearing**
1. Check if CSS and JS files are loaded
2. Verify file paths in your layout files
3. Check browser console for JavaScript errors

### **Styling Issues**
1. Ensure Font Awesome is loaded for icons
2. Check CSS file path in layout files
3. Verify CSS classes are not conflicting

### **JavaScript Errors**
1. Open browser console (F12)
2. Look for error messages
3. Ensure chatbot.js is loaded after DOM elements

## 🔮 Future Enhancements

### **Phase 2: Database Integration**
- [ ] Connect to products table
- [ ] Real-time inventory queries
- [ ] Customer conversation storage
- [ ] Admin conversation management

### **Phase 3: AI Enhancement**
- [ ] Integrate with OpenAI API
- [ ] Natural language processing
- [ ] Context-aware responses
- [ ] Multi-language support

### **Phase 4: Advanced Features**
- [ ] File uploads
- [ ] Voice messages
- [ ] Video calls
- [ ] Integration with CRM

## 📞 Support

If you need help with the chatbot:

1. **Check this README** for common solutions
2. **Review the code** in the files
3. **Test the demo** at `chatbot.html`
4. **Check browser console** for errors

## 📄 License

This chatbot widget is created specifically for RMB Store. Feel free to modify and customize it for your needs.

---

**🎉 Your chatbot is ready to enhance customer experience!**

The chatbot will appear on all your frontend pages, providing instant customer support and engagement. Customers can ask questions about products, get support information, and interact with your brand 24/7.
