// Chatbot JavaScript with Database Integration and AI
class ChatbotWidget {
    constructor() {
        this.isOpen = false;
        this.isTyping = false;
        this.messageCount = 0;
        this.messageHistory = [];
        this.products = [];
        this.qa = [];
        this.apiBase = '/chatbot';
        
        // User session management
        this.sessionId = this.generateSessionId();
        this.userFingerprint = this.generateUserFingerprint();
        
        this.init();
        this.loadProducts();
        this.loadQA();
        this.saveSession();
        this.loadUserHistory(); // Load user-specific chat history
    }
    
    // Generate unique session ID for each user
    generateSessionId() {
        const timestamp = Date.now();
        const random = Math.random().toString(36).substring(2, 15);
        return `session_${timestamp}_${random}`;
    }
    
    // Generate user fingerprint for identification
    generateUserFingerprint() {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        ctx.textBaseline = 'top';
        ctx.font = '14px Arial';
        ctx.fillText('User fingerprint', 2, 2);
        
        const fingerprint = canvas.toDataURL();
        const userAgent = navigator.userAgent;
        const screenRes = `${screen.width}x${screen.height}`;
        const timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
        
        // Create a hash of user characteristics
        const userData = `${fingerprint}_${userAgent}_${screenRes}_${timezone}`;
        return btoa(userData).substring(0, 32); // Base64 encoded, truncated
    }
    
    // Load user-specific chat history
    async loadUserHistory() {
        try {
            const response = await fetch(`${this.apiBase}/getChatHistory`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    sessionId: this.sessionId,
                    userFingerprint: this.userFingerprint
                })
            });
            
            if (response.ok) {
                const data = await response.json();
                if (data.success && data.messages && data.messages.length > 0) {
                    console.log('📚 Loading user chat history:', data.messages.length, 'messages');
                    
                    // Clear current messages
                    this.chatMessages.innerHTML = '';
                    
                    // Load historical messages
                    data.messages.forEach(msg => {
                        this.addMessage(msg.message, msg.sender, false); // false = don't save to DB again
                    });
                    
                    // Update message count
                    this.messageCount = data.messages.length;
                    
                    // Show welcome back message if returning user
                    if (data.messages.length > 0) {
                        this.addMessage(`Welcome back! I remember our previous conversation. How can I help you today?`, 'bot');
                    }
                }
            }
        } catch (error) {
            console.error('Error loading user history:', error);
        }
    }
    
    // Load products from database
    async loadProducts() {
        try {
            const response = await fetch(`${this.apiBase}/getProducts`);
            if (response.ok) {
                const result = await response.json();
                if (result.status === 'success') {
                    this.products = result.data;
                    console.log('Loaded products from database:', this.products.length);
                } else {
                    console.warn('Failed to load products:', result.message);
                    this.loadSampleProducts();
                }
            } else {
                console.warn('Products API not available, using sample data');
                this.loadSampleProducts();
            }
        } catch (error) {
            console.log('Using sample products due to error:', error.message);
            this.loadSampleProducts();
        }
    }
    
    // Load Q&A from database
    async loadQA() {
        try {
            const response = await fetch(`${this.apiBase}/getQA`);
            if (response.ok) {
                const result = await response.json();
                if (result.status === 'success') {
                    this.qa = result.data;
                    console.log('Loaded Q&A from database:', this.qa.length);
                } else {
                    console.warn('Failed to load Q&A:', result.message);
                    this.loadSampleQA(); // Fallback to sample data
                }
            } else {
                console.warn('Q&A API not available');
                this.loadSampleQA(); // Fallback to sample data
            }
        } catch (error) {
            console.log('Q&A loading error:', error.message);
            this.loadSampleQA(); // Fallback to sample data
        }
    }
    
    // Save chat session to database
    async saveSession() {
        try {
            const response = await fetch(`${this.apiBase}/saveSession`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    sessionId: this.sessionId,
                    userFingerprint: this.userFingerprint,
                    userIp: '', // Will be set by server
                    userAgent: navigator.userAgent
                })
            });
            
            if (response.ok) {
                const data = await response.json();
                console.log('Session saved successfully:', data);
            } else {
                console.error('Failed to save session:', response.status);
            }
        } catch (error) {
            console.error('Error saving session:', error);
        }
    }
    
    // Save message to database
    async saveMessage(sender, message, messageType = 'text', metadata = null) {
        try {
            const response = await fetch(`${this.apiBase}/saveMessage`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    sessionId: this.sessionId,
                    userFingerprint: this.userFingerprint,
                    sender: sender,
                    message: message,
                    messageType: messageType,
                    metadata: metadata
                })
            });
            
            if (response.ok) {
                const data = await response.json();
                console.log('Message saved successfully:', data);
            } else {
                console.error('Failed to save message:', response.status);
            }
        } catch (error) {
            console.error('Error saving message:', error);
        }
    }
    
    // Load sample products for demonstration
    loadSampleProducts() {
        this.products = [
            { id: 1, name: 'Nike Air Max 270', category: 'Footwear', price: 129.99, stock: 15, image: '/assets/frontend/images/product1.jpg' },
            { id: 2, name: 'Adidas Ultraboost 21', category: 'Footwear', price: 179.99, stock: 8, image: '/assets/frontend/images/product1.jpg' },
            { id: 3, name: 'Puma RS-X', category: 'Footwear', price: 89.99, stock: 12, image: '/assets/frontend/images/product1.jpg' },
            { id: 4, name: 'Nike Dri-FIT T-Shirt', category: 'Apparel', price: 34.99, stock: 25, image: '/assets/frontend/images/product1.jpg' },
            { id: 5, name: 'Adidas Track Jacket', category: 'Apparel', price: 59.99, stock: 18, image: '/assets/frontend/images/product1.jpg' },
            { id: 6, name: 'Nike Basketball Shorts', category: 'Apparel', price: 44.99, stock: 22, image: '/assets/frontend/images/product1.jpg' },
            { id: 7, name: 'Gym Bag Large', category: 'Accessories', price: 29.99, stock: 30, image: '/assets/frontend/images/product1.jpg' },
            { id: 8, name: 'Water Bottle 32oz', category: 'Accessories', price: 19.99, stock: 45, image: '/assets/frontend/images/product1.jpg' },
            { id: 9, name: 'Sony WH-1000XM4', category: 'Electronics', price: 349.99, stock: 10, image: '/assets/frontend/images/product1.jpg' },
            { id: 10, name: 'Bose QuietComfort 35 II', category: 'Electronics', price: 299.99, stock: 12, image: '/assets/frontend/images/product1.jpg' },
            { id: 11, name: 'Apple AirPods Pro', category: 'Electronics', price: 249.99, stock: 20, image: '/assets/frontend/images/product1.jpg' },
            { id: 12, name: 'JBL Flip 5', category: 'Electronics', price: 119.99, stock: 15, image: '/assets/frontend/images/product1.jpg' }
        ];
    }
    
    // Load sample Q&A for demonstration
    loadSampleQA() {
        this.qa = [
            {
                id: 1,
                question: 'What are your business hours?',
                answer: 'Our business hours are:\n🕐 Monday - Friday: 9:00 AM - 6:00 PM\n🕐 Saturday: 10:00 AM - 4:00 PM\n🕐 Sunday: Closed\n\nWe\'re here to serve you during these times!',
                category: 'business',
                keywords: 'hours,time,open,close,business',
                priority: 1
            },
            {
                id: 2,
                question: 'Do you offer shipping?',
                answer: 'Yes! We offer various shipping options:\n🚚 Standard: 3-5 business days\n🚚 Express: 1-2 business days\n🚚 Same day: Available for local orders\n\nShipping costs vary by location and speed.',
                category: 'shipping',
                keywords: 'shipping,delivery,ship,deliver',
                priority: 1
            },
            {
                id: 3,
                question: 'Do you sell headphones?',
                answer: 'Yes! We have a great selection of headphones including Sony, Bose, and Apple AirPods. We carry both wired and wireless options with noise cancellation features.',
                category: 'products',
                keywords: 'headphones,earbuds,audio,sony,bose,apple',
                priority: 1
            }
        ];
    }
    
    // Search products by query
    searchProducts(query) {
        try {
            const searchTerm = query.toLowerCase();
            return this.products.filter(product => 
                product.name.toLowerCase().includes(searchTerm) ||
                product.category.toLowerCase().includes(searchTerm) ||
                // Check if any word in the product name contains the search term
                product.name.toLowerCase().split(' ').some(word => word.includes(searchTerm)) ||
                // Check if search term contains any word from product name
                product.name.toLowerCase().split(' ').some(word => searchTerm.includes(word))
            );
        } catch (error) {
            console.error('Error in searchProducts:', error);
            return [];
        }
    }
    
    // Search Q&A by query
    searchQA(query) {
        try {
            const searchTerm = query.toLowerCase();
            return this.qa.filter(qa => 
                qa.question.toLowerCase().includes(searchTerm) ||
                qa.answer.toLowerCase().includes(searchTerm) ||
                (qa.keywords && qa.keywords.toLowerCase().includes(searchTerm)) ||
                qa.category.toLowerCase().includes(searchTerm)
            );
        } catch (error) {
            console.error('Error in searchQA:', error);
            return [];
        }
    }
    
    // Handle product link clicks
    handleProductClick(productId, productName) {
        console.log(`Product clicked: ${productName} (ID: ${productId})`);
        
        // You can customize this to open product details in a new tab/window
        // or navigate to the product page
        const productUrl = `/product/${productId}`;
        
        // Open in new tab
        window.open(productUrl, '_blank');
        
        // Add a confirmation message
        this.addMessage(`🔗 Opening product details for "${productName}"...`, 'bot');
    }
    
    // Enhanced product display with clean, professional design
    formatProductDisplayEnhanced(product, index = null) {
        console.log('🎨 formatProductDisplayEnhanced called with:', { product, index });
        
        // Get product image - use available images based on category or fallback
        let productImage = '/assets/frontend/images/product1.jpg'; // default fallback
        
        if (product.category.toLowerCase().includes('footwear') || product.category.toLowerCase().includes('shoes')) {
            productImage = '/assets/frontend/images/product2.jpg';
        } else if (product.category.toLowerCase().includes('apparel') || product.category.toLowerCase().includes('clothes')) {
            productImage = '/assets/frontend/images/product3.jpg';
        } else if (product.category.toLowerCase().includes('electronics') || product.category.toLowerCase().includes('headphone')) {
            productImage = '/assets/frontend/images/product4.jpg';
        } else if (product.category.toLowerCase().includes('accessories')) {
            productImage = '/assets/frontend/images/accessories1.jpg';
        }
        
        console.log('🖼️ Selected product image:', productImage);
        
        // Create clean, professional product card with just image and name
        // Using the correct frontend URL structure: /product/{id}
        const productHTML = `
<div class="product-card-clean">
    <div class="product-image-container">
        <img src="${productImage}" alt="${product.name}" class="product-image-clean">
    </div>
    <div class="product-name-container">
        <a href="/product/${product.id}" class="product-name-link" target="_blank">
            ${product.name}
        </a>
    </div>
</div>`;
        
        console.log('🎨 Generated clean product HTML:', productHTML);
        return productHTML;
    }
    
    // Display multiple products in chat with clean, professional design
    displayProductResults(products, query) {
        console.log('🔍 displayProductResults called with:', { products, query });
        console.log('📦 Products array:', products);
        
        if (products.length === 0) {
            return `Sorry, I couldn't find any products matching "${query}". Try searching for something else or browse our categories: Footwear, Apparel, Accessories, Electronics.`;
        }
        
        let response = `<div class="product-search-container">
            <div class="search-results-header">
                <h3>🔍 Search Results for "${query}"</h3>
                <div class="product-count-badge">Found ${products.length} products</div>
            </div>
            <div class="product-grid">`;
        
        // Display all products in a clean grid
        products.forEach((product, index) => {
            response += this.formatProductDisplayEnhanced(product, index);
        });
        
        response += `</div>
            <div style="text-align: center; margin-top: 12px; font-size: 12px; color: #666;">
                💡 Click on any product to view details
            </div>
        </div>`;
        
        console.log('🎨 Generated clean product results:', response);
        return response;
    }
    
    // Get AI response
    async getAIResponse(message) {
        try {
            const response = await fetch(`${this.apiBase}/getAIResponse`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    message: message
                })
            });
            
            if (response.ok) {
                const result = await response.json();
                if (result.status === 'success') {
                    return result.data.response;
                }
            }
        } catch (error) {
            console.log('AI response failed:', error.message);
        }
        
        return null;
    }
    
    // Initialize DOM elements and event listeners
    init() {
        // DOM Elements
        this.chatButton = document.getElementById('chatButton');
        this.chatWindow = document.getElementById('chatWindow');
        this.chatMessages = document.getElementById('chatMessages');
        this.chatInput = document.getElementById('chatInput');
        this.sendBtn = document.getElementById('sendBtn');
        this.minimizeBtn = document.getElementById('minimizeBtn');
        this.closeBtn = document.getElementById('closeBtn');
        this.typingIndicator = document.getElementById('typingIndicator');
        this.notificationBadge = document.getElementById('notificationBadge');
        this.quickReplies = document.getElementById('quickReplies');
        
        this.initializeEventListeners();
        this.hideNotificationBadge();
    }
    
    initializeEventListeners() {
        // Chat button click
        this.chatButton.addEventListener('click', () => this.toggleChat());
        
        // Send button click
        this.sendBtn.addEventListener('click', () => this.sendMessage());
        
        // Enter key in input
        this.chatInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                this.sendMessage();
            }
        });
        
        // Minimize button
        this.minimizeBtn.addEventListener('click', () => this.minimizeChat());
        
        // Close button
        this.closeBtn.addEventListener('click', () => this.closeChat());
        
        // Quick reply buttons
        this.quickReplies.addEventListener('click', (e) => {
            if (e.target.classList.contains('quick-reply-btn')) {
                const message = e.target.dataset.message;
                this.sendQuickReply(message);
            }
        });
        
        // Click outside to close
        document.addEventListener('click', (e) => {
            if (!this.chatWindow.contains(e.target) && 
                !this.chatButton.contains(e.target) && 
                this.isOpen) {
                this.closeChat();
            }
        });
        
        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => {
            if (e.ctrlKey && e.key === 'k') {
                e.preventDefault();
                this.toggleChat();
            }
            if (e.key === 'Escape' && this.isOpen) {
                this.closeChat();
            }
        });
    }
    
    toggleChat() {
        if (this.isOpen) {
            this.closeChat();
        } else {
            this.openChat();
        }
    }
    
    openChat() {
        this.isOpen = true;
        this.chatWindow.classList.add('open');
        this.chatInput.focus();
        this.hideNotificationBadge();
        this.scrollToBottom();
        
        // Add to message history
        this.addToHistory('system', 'Chat opened');
    }
    
    closeChat() {
        this.isOpen = false;
        this.chatWindow.classList.remove('open');
        this.addToHistory('system', 'Chat closed');
    }
    
    minimizeChat() {
        this.chatWindow.classList.toggle('minimized');
        this.addToHistory('system', 'Chat minimized');
    }
    
    async sendMessage() {
        const message = this.chatInput.value.trim();
        if (!message) return;
        
        // Add user message
        this.addMessage(message, 'user');
        this.addToHistory('user', message);
        this.saveMessage('user', message, 'text');
        
        // Clear input
        this.chatInput.value = '';
        
        // Show typing indicator
        this.showTypingIndicator();
        
        // Generate and show response
        try {
            const response = await this.generateResponse(message);
            this.hideTypingIndicator();
            this.addMessage(response, 'bot');
            this.addToHistory('bot', response);
            this.saveMessage('bot', response, 'text');
        } catch (error) {
            this.hideTypingIndicator();
            const fallbackResponse = "I'm sorry, I'm having trouble processing your request right now. Please try again in a moment.";
            this.addMessage(fallbackResponse, 'bot');
            this.addToHistory('bot', fallbackResponse);
            this.saveMessage('bot', fallbackResponse, 'text');
        }
    }
    
    sendQuickReply(message) {
        this.chatInput.value = message;
        this.sendMessage();
    }
    
    addMessage(text, sender, saveToDatabase = true) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${sender}-message`;
        messageDiv.dataset.sender = sender;
        messageDiv.dataset.timestamp = Date.now().toString();
        
        const messageContent = document.createElement('div');
        messageContent.className = 'message-content';
        
        const avatar = document.createElement('div');
        avatar.className = 'avatar';
        avatar.innerHTML = sender === 'user' ? '👤' : '🤖';
        
        const messageText = document.createElement('div');
        messageText.className = 'message-text';
        
        // Handle HTML content for bot messages, escape HTML for user messages
        if (sender === 'bot') {
            messageText.innerHTML = text; // Allow HTML for bot messages (product links)
        } else {
            messageText.textContent = text; // Escape HTML for user messages
        }
        
        const timestamp = document.createElement('div');
        timestamp.className = 'timestamp';
        timestamp.textContent = this.getCurrentTime();
        
        messageContent.appendChild(avatar);
        messageContent.appendChild(messageText);
        messageContent.appendChild(timestamp);
        
        messageDiv.appendChild(messageContent);
        
        // Add to chat
        this.chatMessages.appendChild(messageDiv);
        
        // Update message count
        this.messageCount = this.chatMessages.children.length;
        
        // Scroll to bottom
        this.scrollToBottom();
        
        // Add slide-up animation
        setTimeout(() => {
            messageDiv.classList.add('slide-up');
        }, 100);
        
        // Save to database only if requested (not for historical messages)
        if (saveToDatabase) {
            this.saveMessage(sender, text);
        }
        
        // Debug logging
        console.log(`Message successfully added: ${sender} - "${text}"`);
        console.log(`Total messages in chat: ${this.chatMessages.children.length}`);
        console.log(`Session ID: ${this.sessionId}`);
        
        return messageDiv;
    }
    
    // Remove problematic message monitoring
    // startMessageMonitoring() { ... }
    
    showTypingIndicator() {
        this.isTyping = true;
        this.typingIndicator.classList.add('show');
        this.sendBtn.disabled = true;
        this.scrollToBottom();
    }
    
    hideTypingIndicator() {
        this.isTyping = false;
        this.typingIndicator.classList.remove('show');
        this.sendBtn.disabled = false;
    }
    
    scrollToBottom() {
        setTimeout(() => {
            this.chatMessages.scrollTop = this.chatMessages.scrollHeight;
        }, 100);
    }
    
    getCurrentTime() {
        const now = new Date();
        let hours = now.getHours();
        const minutes = now.getMinutes().toString().padStart(2, '0');
        const ampm = hours >= 12 ? 'PM' : 'AM';
        
        // Convert to 12-hour format
        hours = hours % 12;
        hours = hours ? hours : 12; // Convert 0 to 12
        
        return `${hours}:${minutes} ${ampm}`;
    }
    
    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
    
    showNotificationBadge() {
        if (this.notificationBadge) {
            this.notificationBadge.style.display = 'flex';
        }
    }
    
    hideNotificationBadge() {
        if (this.notificationBadge) {
            this.notificationBadge.style.display = 'none';
        }
    }
    
    addToHistory(sender, message) {
        this.messageHistory.push({
            sender: sender,
            message: message,
            timestamp: new Date().toISOString()
        });
        
        // Keep only last 100 messages
        if (this.messageHistory.length > 100) {
            this.messageHistory.shift();
        }
        
        // Save to localStorage
        this.saveChatHistory();
    }
    
    saveChatHistory() {
        try {
            localStorage.setItem(`chatbot_history_${this.sessionId}`, JSON.stringify(this.messageHistory));
        } catch (e) {
            console.warn('Could not save chat history to localStorage:', e);
        }
    }
    
    loadChatHistory() {
        try {
            const saved = localStorage.getItem(`chatbot_history_${this.sessionId}`);
            if (saved) {
                this.messageHistory = JSON.parse(saved);
                console.log('Loaded chat history:', this.messageHistory.length, 'messages');
                
                // Only restore if this is a new session and we have previous messages
                if (this.messageHistory.length > 0 && this.messageHistory.some(item => item.sender !== 'system')) {
                    this.restoreMessagesFromHistory();
                }
            }
        } catch (e) {
            console.warn('Could not load chat history to localStorage:', e);
        }
    }
    
    restoreMessagesFromHistory() {
        // Don't restore if chat is already open with messages
        if (this.chatMessages.children.length > 1) {
            console.log('Chat already has messages, skipping restoration');
            return;
        }
        
        console.log('Restoring messages from history...');
        
        // Clear existing messages first
        this.chatMessages.innerHTML = '';
        
        // Add welcome message
        this.addMessage("👋 Hello! I'm your AI assistant. How can I help you today?", 'bot');
        
        // Restore conversation history
        this.messageHistory.forEach(historyItem => {
            if (historyItem.sender !== 'system') {
                this.addMessage(historyItem.message, historyItem.sender);
            }
        });
        
        console.log('Restored', this.messageHistory.length, 'messages from history');
    }
    
    async generateResponse(userMessage) {
        try {
            const message = userMessage.toLowerCase();
            
            // Ensure arrays exist and are arrays
            if (!Array.isArray(this.products)) {
                console.warn('Products array is not available, loading sample data');
                this.loadSampleProducts();
            }
            if (!Array.isArray(this.qa)) {
                console.warn('Q&A array is not available, loading sample data');
                this.loadSampleQA();
            }
            
            console.log('🔍 Processing message:', userMessage);
            console.log('📦 Available products:', this.products?.length || 0);
            console.log('📚 Available Q&A:', this.qa?.length || 0);
            
            // FIRST PRIORITY: Direct product queries - improved matching
            const productKeywords = ['nike', 'adidas', 'puma', 'sony', 'bose', 'apple', 'jbl', 'headphone', 'headphones', 'earbuds', 'shoes', 'sneakers', 'shirt', 'jacket', 'bag', 'bottle'];
            const foundKeyword = productKeywords.find(keyword => message.includes(keyword));
            
            if (foundKeyword) {
                console.log('🎯 Found product keyword:', foundKeyword);
                const results = this.searchProducts(foundKeyword);
                console.log('📦 Product search results for', foundKeyword, ':', results);
                if (results.length > 0) {
                    return this.displayProductResults(results, foundKeyword);
                }
            }
            
            // SECOND PRIORITY: Category-based search
            if (message.includes('footwear') || message.includes('shoes') || message.includes('sneakers')) {
                const results = this.searchProducts('footwear');
                return this.displayProductResults(results, 'footwear');
            }
            
            if (message.includes('apparel') || message.includes('clothes') || message.includes('shirt') || message.includes('jacket')) {
                const results = this.searchProducts('apparel');
                return this.displayProductResults(results, 'apparel');
            }
            
            if (message.includes('accessories') || message.includes('bag') || message.includes('bottle')) {
                const results = this.searchProducts('accessories');
                return this.displayProductResults(results, 'accessories');
            }
            
            if (message.includes('electronics') || message.includes('headphone') || message.includes('earbuds') || message.includes('speaker')) {
                const results = this.searchProducts('electronics');
                return this.displayProductResults(results, 'electronics');
            }
            
            // THIRD PRIORITY: Search commands
            if (message.includes('search') || message.includes('find') || message.includes('look for')) {
                const searchQuery = userMessage.replace(/search|find|look for/gi, '').trim();
                if (searchQuery) {
                    console.log('🔍 Searching for products with query:', searchQuery);
                    const results = this.searchProducts(searchQuery);
                    console.log('📦 Search results:', results);
                    return this.displayProductResults(results, searchQuery);
                }
            }
            
            // FOURTH PRIORITY: Q&A match (moved to lower priority)
            const qaMatch = this.searchQA(userMessage);
            if (qaMatch.length > 0) {
                console.log('✅ Found Q&A match:', qaMatch[0].question);
                // Return the best match (highest priority first)
                const bestMatch = qaMatch.sort((a, b) => (b.priority || 1) - (a.priority || 1))[0];
                return bestMatch.answer;
            }
            
            console.log('❌ No specific matches found, using default responses');
            
            // Product-related responses
            if (message.includes('product') || message.includes('item') || message.includes('goods')) {
                return "We offer a wide range of products! You can search for specific items by typing 'search [product name]' or ask me about categories like Footwear, Apparel, Accessories, or Electronics. What are you looking for?";
            }
            
            if (message.includes('price') || message.includes('cost') || message.includes('how much')) {
                return "Our prices vary by product and category. You can search for specific products to see their prices, or ask me about a particular item you're interested in.";
            }
            
            if (message.includes('stock') || message.includes('available') || message.includes('in stock')) {
                return "I can check stock availability for you! Just search for the product you're interested in, and I'll show you the current stock status.";
            }
            
            // Support-related responses
            if (message.includes('support') || message.includes('help') || message.includes('assist')) {
                return "I'm here to help! I can help you search for products, check prices and stock, or answer questions about our store. You can also contact our support team at support@rmbstore.com. What do you need help with?";
            }
            
            if (message.includes('contact') || message.includes('phone') || message.includes('email')) {
                return "You can reach us through multiple channels:\n📧 Email: info@rmbstore.com\n📞 Phone: +1 (555) 123-4567\n💬 Live chat: Right here!\n\nWhat's the best way to help you?";
            }
            
            // Business hours
            if (message.includes('hours') || message.includes('time') || message.includes('open') || message.includes('close')) {
                return "Our business hours are:\n🕐 Monday - Friday: 9:00 AM - 6:00 PM\n🕐 Saturday: 10:00 AM - 4:00 PM\n🕐 Sunday: Closed\n\nWe're here to serve you during these times!";
            }
            
            // Shipping and delivery
            if (message.includes('shipping') || message.includes('delivery') || message.includes('ship')) {
                return "We offer various shipping options:\n🚚 Standard: 3-5 business days\n🚚 Express: 1-2 business days\n🚚 Same day: Available for local orders\n\nShipping costs vary by location and speed.";
            }
            
            // Returns and refunds
            if (message.includes('return') || message.includes('refund') || message.includes('exchange')) {
                return "We have a 30-day return policy for most items. Products must be in original condition with tags attached. For returns, please contact our customer service team.";
            }
            
            // Greetings
            if (message.includes('hello') || message.includes('hi') || message.includes('hey')) {
                return "Hello! 👋 Welcome to RMB Store. I'm here to help you find products, check prices and stock, and answer any questions. You can search for products by typing 'search [product name]' or ask me about specific categories. How can I assist you today?";
            }
            
            if (message.includes('thank') || message.includes('thanks')) {
                return "You're very welcome! 😊 Is there anything else I can help you with today?";
            }
            
            // Try AI response for complex queries
            const aiResponse = await this.getAIResponse(userMessage);
            if (aiResponse) {
                return aiResponse;
            }
            
            // Default responses with search suggestions
            const defaultResponses = [
                "That's an interesting question! I can help you search for products, check prices, or find specific items. Try typing 'search [product name]' or ask me about our categories.",
                "I'd be happy to help with that! I can search our product database, check stock availability, or help you find what you're looking for. What would you like to know?",
                "Great question! I can search for products, show you categories, or help you find specific items. Just let me know what you're looking for!",
                "I'm here to help! I can search our products, check prices and stock, or answer questions about our store. What can I assist you with?",
                "That's something I can help you with! I can search for products, show you categories, or help you find specific items. What are you looking for?"
            ];
            
            return defaultResponses[Math.floor(Math.random() * defaultResponses.length)];
            
        } catch (error) {
            console.error('❌ Error in generateResponse:', error);
            return "I'm sorry, I encountered an error while processing your request. Please try again or ask me something else.";
        }
    }
    
    // Method to clear chat history
    clearChatHistory() {
        this.messageHistory = [];
        this.chatMessages.innerHTML = '';
        this.saveChatHistory();
        
        // Add welcome message back
        this.addMessage("👋 Hello! I'm your AI assistant. How can I help you today?", 'bot');
    }
    
    // Method to export chat history
    exportChatHistory() {
        const dataStr = JSON.stringify(this.messageHistory, null, 2);
        const dataBlob = new Blob([dataStr], {type: 'application/json'});
        const url = URL.createObjectURL(dataBlob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `chat_history_${this.sessionId}.json`;
        link.click();
        URL.revokeObjectURL(url);
    }
    
    // Method to refresh chat display
    refreshChatDisplay() {
        console.log('Refreshing chat display...');
        const currentMessages = Array.from(this.chatMessages.children);
        const messageData = [];
        
        // Extract message data
        currentMessages.forEach(msg => {
            if (msg.classList.contains('message')) {
                const sender = msg.dataset.sender || 'unknown';
                const text = msg.querySelector('.message-text')?.textContent || '';
                if (text) {
                    messageData.push({ sender, text });
                }
            }
        });
        
        // Clear and rebuild
        this.chatMessages.innerHTML = '';
        
        // Re-add welcome message
        this.addMessage("👋 Hello! I'm your AI assistant. How can I help you today?", 'bot');
        
        // Re-add all messages
        messageData.forEach(({ sender, text }) => {
            this.addMessage(text, sender);
        });
        
        console.log('Chat display refreshed with', messageData.length, 'messages');
    }
}

// Initialize chatbot when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.chatbot = new ChatbotWidget();
    
    // Show notification badge after 5 seconds if chat is not open
    setTimeout(() => {
        if (!window.chatbot.isOpen) {
            window.chatbot.showNotificationBadge();
        }
    }, 5000);
});

// Add some helpful console messages
document.addEventListener('keydown', (e) => {
    if (e.ctrlKey && e.key === 'k') {
        console.log('🎯 Chatbot shortcut: Ctrl+K pressed');
    }
});

// Export for use in other scripts
if (typeof module !== 'undefined' && module.exports) {
    module.exports = ChatbotWidget;
}
