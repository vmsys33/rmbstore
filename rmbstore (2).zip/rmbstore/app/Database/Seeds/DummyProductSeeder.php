<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class DummyProductSeeder extends Seeder
{
    public function run()
    {
        $productModel = new \App\Models\ProductModel();
        $categoryModel = new \App\Models\CategoryModel();
        
        // Get existing categories
        $categories = $categoryModel->findAll();
        if (empty($categories)) {
            echo "No categories found. Please run CategorySeeder first.\n";
            return;
        }
        
        // Dummy product data
        $dummyProducts = [
            [
                'product_name' => 'Premium Wireless Headphones',
                'slug' => 'premium-wireless-headphones',
                'product_category' => $categories[0]['id'],
                'description' => 'High-quality wireless headphones with noise cancellation and premium sound quality. Perfect for music lovers and professionals.',
                'short_description' => 'Premium wireless headphones with noise cancellation',
                'price' => 299.99,
                'sale_price' => 249.99,
                'stock_quantity' => 45,
                'sku' => 'WH-001',
                'weight' => 0.3,
                'dimensions' => '20x15x8 cm',
                'featured_image' => 'assets/frontend/images/products/headphones.jpg',
                'meta_title' => 'Premium Wireless Headphones - Best Audio Quality',
                'meta_description' => 'Experience premium sound with our wireless headphones featuring noise cancellation technology.',
                'meta_keywords' => 'headphones, wireless, noise cancellation, premium audio',
                'status' => 'active',
                'featured' => 1
            ],
            [
                'product_name' => 'Smart Fitness Watch',
                'slug' => 'smart-fitness-watch',
                'product_category' => $categories[0]['id'],
                'description' => 'Advanced fitness tracking watch with heart rate monitor, GPS, and smartphone connectivity. Track your workouts and health metrics.',
                'short_description' => 'Advanced fitness tracking with heart rate monitor',
                'price' => 199.99,
                'sale_price' => 179.99,
                'stock_quantity' => 32,
                'sku' => 'FW-002',
                'weight' => 0.05,
                'dimensions' => '4x4x1 cm',
                'featured_image' => 'assets/frontend/images/products/smartwatch.jpg',
                'meta_title' => 'Smart Fitness Watch - Track Your Health',
                'meta_description' => 'Monitor your fitness goals with our advanced smartwatch featuring heart rate and GPS tracking.',
                'meta_keywords' => 'smartwatch, fitness, heart rate, GPS, health tracking',
                'status' => 'active',
                'featured' => 1
            ],
            [
                'product_name' => 'Ultra HD 4K Camera',
                'slug' => 'ultra-hd-4k-camera',
                'product_category' => $categories[0]['id'],
                'description' => 'Professional 4K camera with advanced autofocus and image stabilization. Perfect for photography enthusiasts and content creators.',
                'short_description' => 'Professional 4K camera with advanced features',
                'price' => 899.99,
                'sale_price' => 799.99,
                'stock_quantity' => 18,
                'sku' => 'CAM-003',
                'weight' => 0.8,
                'dimensions' => '15x12x8 cm',
                'featured_image' => 'assets/frontend/images/products/camera.jpg',
                'meta_title' => 'Ultra HD 4K Camera - Professional Photography',
                'meta_description' => 'Capture stunning 4K videos and photos with our professional camera featuring advanced autofocus.',
                'meta_keywords' => 'camera, 4K, professional, photography, autofocus',
                'status' => 'active',
                'featured' => 0
            ],
            [
                'product_name' => 'Gaming Laptop Pro',
                'slug' => 'gaming-laptop-pro',
                'product_category' => $categories[0]['id'],
                'description' => 'High-performance gaming laptop with RTX graphics, fast processor, and high refresh rate display. Dominate your games.',
                'short_description' => 'High-performance gaming laptop with RTX graphics',
                'price' => 1499.99,
                'sale_price' => 1299.99,
                'stock_quantity' => 25,
                'sku' => 'GL-004',
                'weight' => 2.5,
                'dimensions' => '35x25x2 cm',
                'featured_image' => 'assets/frontend/images/products/gaming-laptop.jpg',
                'meta_title' => 'Gaming Laptop Pro - Ultimate Gaming Experience',
                'meta_description' => 'Experience ultimate gaming performance with our RTX-powered gaming laptop featuring high refresh rate display.',
                'meta_keywords' => 'gaming laptop, RTX, high performance, gaming',
                'status' => 'active',
                'featured' => 1
            ],
            [
                'product_name' => 'Wireless Bluetooth Speaker',
                'slug' => 'wireless-bluetooth-speaker',
                'product_category' => $categories[0]['id'],
                'description' => 'Portable Bluetooth speaker with 360-degree sound and waterproof design. Perfect for outdoor activities and parties.',
                'short_description' => 'Portable Bluetooth speaker with 360-degree sound',
                'price' => 89.99,
                'sale_price' => 69.99,
                'stock_quantity' => 67,
                'sku' => 'BS-005',
                'weight' => 0.4,
                'dimensions' => '12x12x12 cm',
                'featured_image' => 'assets/frontend/images/products/bluetooth-speaker.jpg',
                'meta_title' => 'Wireless Bluetooth Speaker - Portable Sound',
                'meta_description' => 'Enjoy 360-degree sound with our portable Bluetooth speaker featuring waterproof design.',
                'meta_keywords' => 'bluetooth speaker, portable, waterproof, 360-degree sound',
                'status' => 'active',
                'featured' => 0
            ],
            [
                'product_name' => 'Mechanical Gaming Keyboard',
                'slug' => 'mechanical-gaming-keyboard',
                'product_category' => $categories[0]['id'],
                'description' => 'RGB mechanical keyboard with customizable switches and macro keys. Enhance your gaming and typing experience.',
                'short_description' => 'RGB mechanical keyboard with customizable switches',
                'price' => 159.99,
                'sale_price' => 129.99,
                'stock_quantity' => 41,
                'sku' => 'KB-006',
                'weight' => 1.2,
                'dimensions' => '45x15x3 cm',
                'featured_image' => 'assets/frontend/images/products/gaming-keyboard.jpg',
                'meta_title' => 'Mechanical Gaming Keyboard - RGB Customizable',
                'meta_description' => 'Customize your gaming experience with our RGB mechanical keyboard featuring macro keys.',
                'meta_keywords' => 'gaming keyboard, mechanical, RGB, customizable, macro keys',
                'status' => 'active',
                'featured' => 0
            ],
            [
                'product_name' => '4K Smart TV 55"',
                'slug' => '4k-smart-tv-55',
                'product_category' => $categories[0]['id'],
                'description' => '55-inch 4K Smart TV with HDR technology and built-in streaming apps. Transform your living room entertainment.',
                'short_description' => '55-inch 4K Smart TV with HDR technology',
                'price' => 699.99,
                'sale_price' => 599.99,
                'stock_quantity' => 28,
                'sku' => 'TV-007',
                'weight' => 15.0,
                'dimensions' => '125x75x8 cm',
                'featured_image' => 'assets/frontend/images/products/smart-tv.jpg',
                'meta_title' => '4K Smart TV 55" - Ultimate Home Entertainment',
                'meta_description' => 'Experience stunning 4K visuals with our 55-inch Smart TV featuring HDR and streaming apps.',
                'meta_keywords' => 'smart tv, 4K, HDR, streaming, home entertainment',
                'status' => 'active',
                'featured' => 1
            ],
            [
                'product_name' => 'Wireless Gaming Mouse',
                'slug' => 'wireless-gaming-mouse',
                'product_category' => $categories[0]['id'],
                'description' => 'High-precision wireless gaming mouse with adjustable DPI and programmable buttons. Dominate your games with precision.',
                'short_description' => 'High-precision wireless gaming mouse with adjustable DPI',
                'price' => 79.99,
                'sale_price' => 59.99,
                'stock_quantity' => 53,
                'sku' => 'GM-008',
                'weight' => 0.12,
                'dimensions' => '12x6x4 cm',
                'featured_image' => 'assets/frontend/images/products/gaming-mouse.jpg',
                'meta_title' => 'Wireless Gaming Mouse - Precision Gaming',
                'meta_description' => 'Achieve gaming precision with our wireless gaming mouse featuring adjustable DPI and programmable buttons.',
                'meta_keywords' => 'gaming mouse, wireless, adjustable DPI, programmable buttons',
                'status' => 'active',
                'featured' => 0
            ],
            [
                'product_name' => 'Portable Power Bank',
                'slug' => 'portable-power-bank',
                'product_category' => $categories[0]['id'],
                'description' => '20000mAh portable power bank with fast charging and multiple USB ports. Keep your devices powered on the go.',
                'short_description' => '20000mAh portable power bank with fast charging',
                'price' => 49.99,
                'sale_price' => 39.99,
                'stock_quantity' => 89,
                'sku' => 'PB-009',
                'weight' => 0.35,
                'dimensions' => '15x8x2 cm',
                'featured_image' => 'assets/frontend/images/products/power-bank.jpg',
                'meta_title' => 'Portable Power Bank - Stay Charged Anywhere',
                'meta_description' => 'Never run out of power with our 20000mAh portable power bank featuring fast charging technology.',
                'meta_keywords' => 'power bank, portable, fast charging, 20000mAh, USB',
                'status' => 'active',
                'featured' => 0
            ],
            [
                'product_name' => 'Smart Home Hub',
                'slug' => 'smart-home-hub',
                'product_category' => $categories[0]['id'],
                'description' => 'Centralized smart home hub to control all your smart devices. Create the perfect automated home environment.',
                'short_description' => 'Centralized smart home hub for device control',
                'price' => 129.99,
                'sale_price' => 99.99,
                'stock_quantity' => 34,
                'sku' => 'SH-010',
                'weight' => 0.2,
                'dimensions' => '10x10x3 cm',
                'featured_image' => 'assets/frontend/images/products/smart-hub.jpg',
                'meta_title' => 'Smart Home Hub - Control Your Smart Home',
                'meta_description' => 'Centralize control of all your smart devices with our comprehensive smart home hub.',
                'meta_keywords' => 'smart home hub, automation, device control, IoT',
                'status' => 'active',
                'featured' => 0
            ],
            [
                'product_name' => 'Wireless Earbuds Pro',
                'slug' => 'wireless-earbuds-pro',
                'product_category' => $categories[0]['id'],
                'description' => 'Premium wireless earbuds with active noise cancellation and premium sound quality. Perfect for music and calls.',
                'short_description' => 'Premium wireless earbuds with noise cancellation',
                'price' => 199.99,
                'sale_price' => 169.99,
                'stock_quantity' => 56,
                'sku' => 'EB-011',
                'weight' => 0.08,
                'dimensions' => '3x2x2 cm',
                'featured_image' => 'assets/frontend/images/products/wireless-earbuds.jpg',
                'meta_title' => 'Wireless Earbuds Pro - Premium Audio Experience',
                'meta_description' => 'Experience premium audio with our wireless earbuds featuring active noise cancellation.',
                'meta_keywords' => 'wireless earbuds, noise cancellation, premium audio, bluetooth',
                'status' => 'active',
                'featured' => 1
            ],
            [
                'product_name' => 'Gaming Monitor 27"',
                'slug' => 'gaming-monitor-27',
                'product_category' => $categories[0]['id'],
                'description' => '27-inch gaming monitor with 144Hz refresh rate and 1ms response time. Dominate your games with smooth visuals.',
                'short_description' => '27-inch gaming monitor with 144Hz refresh rate',
                'price' => 349.99,
                'sale_price' => 299.99,
                'stock_quantity' => 38,
                'sku' => 'GM-012',
                'weight' => 4.5,
                'dimensions' => '62x35x20 cm',
                'featured_image' => 'assets/frontend/images/products/gaming-monitor.jpg',
                'meta_title' => 'Gaming Monitor 27" - Smooth Gaming Experience',
                'meta_description' => 'Achieve smooth gaming with our 27-inch monitor featuring 144Hz refresh rate and 1ms response time.',
                'meta_keywords' => 'gaming monitor, 144Hz, 1ms response, 27-inch, gaming',
                'status' => 'active',
                'featured' => 0
            ],
            [
                'product_name' => 'Smartphone Stand',
                'slug' => 'smartphone-stand',
                'product_category' => $categories[0]['id'],
                'description' => 'Adjustable smartphone stand with wireless charging capability. Perfect for desk organization and convenient charging.',
                'short_description' => 'Adjustable smartphone stand with wireless charging',
                'price' => 39.99,
                'sale_price' => 29.99,
                'stock_quantity' => 72,
                'sku' => 'SS-013',
                'weight' => 0.3,
                'dimensions' => '12x8x15 cm',
                'featured_image' => 'assets/frontend/images/products/smartphone-stand.jpg',
                'meta_title' => 'Smartphone Stand - Wireless Charging Stand',
                'meta_description' => 'Organize your desk with our adjustable smartphone stand featuring wireless charging capability.',
                'meta_keywords' => 'smartphone stand, wireless charging, adjustable, desk organizer',
                'status' => 'active',
                'featured' => 0
            ],
            [
                'product_name' => 'USB-C Hub',
                'slug' => 'usb-c-hub',
                'product_category' => $categories[0]['id'],
                'description' => 'Multi-port USB-C hub with HDMI, USB-A, and SD card reader. Expand your device connectivity options.',
                'short_description' => 'Multi-port USB-C hub with HDMI and USB-A',
                'price' => 59.99,
                'sale_price' => 49.99,
                'stock_quantity' => 45,
                'sku' => 'UH-014',
                'weight' => 0.15,
                'dimensions' => '8x4x1 cm',
                'featured_image' => 'assets/frontend/images/products/usb-c-hub.jpg',
                'meta_title' => 'USB-C Hub - Expand Your Connectivity',
                'meta_description' => 'Expand your device connectivity with our multi-port USB-C hub featuring HDMI and SD card reader.',
                'meta_keywords' => 'USB-C hub, multi-port, HDMI, SD card reader, connectivity',
                'status' => 'active',
                'featured' => 0
            ],
            [
                'product_name' => 'Wireless Charging Pad',
                'slug' => 'wireless-charging-pad',
                'product_category' => $categories[0]['id'],
                'description' => 'Fast wireless charging pad with LED indicator and non-slip design. Charge your compatible devices wirelessly.',
                'short_description' => 'Fast wireless charging pad with LED indicator',
                'price' => 34.99,
                'sale_price' => 24.99,
                'stock_quantity' => 61,
                'sku' => 'WC-015',
                'weight' => 0.2,
                'dimensions' => '10x10x1 cm',
                'featured_image' => 'assets/frontend/images/products/wireless-charger.jpg',
                'meta_title' => 'Wireless Charging Pad - Fast Wireless Charging',
                'meta_description' => 'Experience fast wireless charging with our charging pad featuring LED indicator and non-slip design.',
                'meta_keywords' => 'wireless charging pad, fast charging, LED indicator, non-slip',
                'status' => 'active',
                'featured' => 0
            ],
            [
                'product_name' => 'Bluetooth Keyboard',
                'slug' => 'bluetooth-keyboard',
                'product_category' => $categories[0]['id'],
                'description' => 'Slim Bluetooth keyboard with scissor-switch keys and long battery life. Perfect for tablets and mobile devices.',
                'short_description' => 'Slim Bluetooth keyboard with scissor-switch keys',
                'price' => 69.99,
                'sale_price' => 54.99,
                'stock_quantity' => 47,
                'sku' => 'BK-016',
                'weight' => 0.4,
                'dimensions' => '28x12x1 cm',
                'featured_image' => 'assets/frontend/images/products/bluetooth-keyboard.jpg',
                'meta_title' => 'Bluetooth Keyboard - Slim and Portable',
                'meta_description' => 'Enhance your productivity with our slim Bluetooth keyboard featuring scissor-switch keys.',
                'meta_keywords' => 'bluetooth keyboard, slim, portable, scissor-switch, productivity',
                'status' => 'active',
                'featured' => 0
            ],
            [
                'product_name' => 'Webcam HD',
                'slug' => 'webcam-hd',
                'product_category' => $categories[0]['id'],
                'description' => 'HD webcam with built-in microphone and privacy cover. Perfect for video calls, streaming, and content creation.',
                'short_description' => 'HD webcam with built-in microphone and privacy cover',
                'price' => 79.99,
                'sale_price' => 64.99,
                'stock_quantity' => 39,
                'sku' => 'WC-017',
                'weight' => 0.25,
                'dimensions' => '8x6x4 cm',
                'featured_image' => 'assets/frontend/images/products/webcam.jpg',
                'meta_title' => 'Webcam HD - Professional Video Calls',
                'meta_description' => 'Make professional video calls with our HD webcam featuring built-in microphone and privacy cover.',
                'meta_keywords' => 'webcam, HD, microphone, privacy cover, video calls',
                'status' => 'active',
                'featured' => 0
            ],
            [
                'product_name' => 'Tablet Stand',
                'slug' => 'tablet-stand',
                'product_category' => $categories[0]['id'],
                'description' => 'Adjustable tablet stand with multiple viewing angles and sturdy construction. Perfect for hands-free tablet use.',
                'short_description' => 'Adjustable tablet stand with multiple viewing angles',
                'price' => 29.99,
                'sale_price' => 19.99,
                'stock_quantity' => 58,
                'sku' => 'TS-018',
                'weight' => 0.5,
                'dimensions' => '20x15x25 cm',
                'featured_image' => 'assets/frontend/images/products/tablet-stand.jpg',
                'meta_title' => 'Tablet Stand - Hands-Free Tablet Use',
                'meta_description' => 'Enjoy hands-free tablet use with our adjustable stand featuring multiple viewing angles.',
                'meta_keywords' => 'tablet stand, adjustable, multiple angles, hands-free',
                'status' => 'active',
                'featured' => 0
            ],
            [
                'product_name' => 'Cable Organizer',
                'slug' => 'cable-organizer',
                'product_category' => $categories[0]['id'],
                'description' => 'Multi-purpose cable organizer with adhesive backing and multiple sizes. Keep your cables neat and organized.',
                'short_description' => 'Multi-purpose cable organizer with adhesive backing',
                'price' => 19.99,
                'sale_price' => 14.99,
                'stock_quantity' => 83,
                'sku' => 'CO-019',
                'weight' => 0.1,
                'dimensions' => '15x5x2 cm',
                'featured_image' => 'assets/frontend/images/products/cable-organizer.jpg',
                'meta_title' => 'Cable Organizer - Keep Cables Neat',
                'meta_description' => 'Organize your cables with our multi-purpose organizer featuring adhesive backing and multiple sizes.',
                'meta_keywords' => 'cable organizer, adhesive, multi-purpose, cable management',
                'status' => 'active',
                'featured' => 0
            ],
            [
                'product_name' => 'Desk Lamp LED',
                'slug' => 'desk-lamp-led',
                'product_category' => $categories[0]['id'],
                'description' => 'Modern LED desk lamp with adjustable brightness and color temperature. Perfect for work and study environments.',
                'short_description' => 'Modern LED desk lamp with adjustable brightness',
                'price' => 89.99,
                'sale_price' => 69.99,
                'stock_quantity' => 42,
                'sku' => 'DL-020',
                'weight' => 1.8,
                'dimensions' => '45x25x60 cm',
                'featured_image' => 'assets/frontend/images/products/desk-lamp.jpg',
                'meta_title' => 'Desk Lamp LED - Modern Lighting Solution',
                'meta_description' => 'Illuminate your workspace with our modern LED desk lamp featuring adjustable brightness and color temperature.',
                'meta_keywords' => 'desk lamp, LED, adjustable brightness, color temperature, modern',
                'status' => 'active',
                'featured' => 0
            ]
        ];
        
        $insertedCount = 0;
        
        foreach ($dummyProducts as $product) {
            // Check if product already exists
            $existingProduct = $productModel->where('slug', $product['slug'])->first();
            
            if (!$existingProduct) {
                $productModel->insert($product);
                $insertedCount++;
                echo "Added product: {$product['product_name']}\n";
            } else {
                echo "Product already exists: {$product['product_name']}\n";
            }
        }
        
        echo "\nDummy product seeding completed!\n";
        echo "Total products added: {$insertedCount}\n";
        echo "Total products in database: " . $productModel->countAllResults() . "\n";
    }
}
