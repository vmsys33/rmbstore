<footer class="geex-footer">
	<div class="geex-footer__wrap">
		<div class="geex-footer__copyright">
			<p><span>© 2025 </span><a href="https://themeforest.net/user/pixcelsthemes">PixcelsThemes</a></p>
		</div>
		<ul class="geex-footer__menu">
			<li class="geex-footer__meu__item">
				<a href="<?= route_to('terms') ?>">Privacy</a>
			</li>
			<li class="geex-footer__meu__item">
				<a href="<?= route_to('blog') ?>">Blog</a>
			</li>
			<li class="geex-footer__meu__item">
				<a href="<?= route_to('faq') ?>">Faq</a>
			</li>
		</ul>
	</div>
</footer>