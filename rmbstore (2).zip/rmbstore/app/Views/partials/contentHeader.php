
<div class="geex-content__header">
    <div class="geex-content__header__content">
        <h2 class="geex-content__header__title"><?= $title ?></h2>
        <p class="geex-content__header__subtitle"><?= $subTitle ?></p>
    </div>

    <div class="geex-content__header__action">
   
        <div class="geex-content__header__action__wrap">
            <ul class="geex-content__header__quickaction">
                <li class="geex-content__header__quickaction__item">
                    <a href="#" class="geex-content__header__quickaction__link">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M2 10C2 12.1217 2.84285 14.1566 4.34315 15.6569C5.84344 17.1571 7.87827 18 10 18C11.7767 18.0022 13.5025 17.407 14.9 16.31L19.29 20.71C19.383 20.8037 19.4936 20.8781 19.6154 20.9289C19.7373 20.9797 19.868 21.0058 20 21.0058C20.132 21.0058 20.2627 20.9797 20.3846 20.9289C20.5064 20.8781 20.617 20.8037 20.71 20.71C20.8037 20.617 20.8781 20.5064 20.9289 20.3846C20.9797 20.2627 21.0058 20.132 21.0058 20C21.0058 19.868 20.9797 19.7373 20.9289 19.6154C20.8781 19.4936 20.8037 19.383 20.71 19.29L16.31 14.9C17.407 13.5025 18.0022 11.7767 18 10C18 7.87827 17.1571 5.84344 15.6569 4.34315C14.1566 2.84285 12.1217 2 10 2C7.87827 2 5.84344 2.84285 4.34315 4.34315C2.84285 5.84344 2 7.87827 2 10ZM10 4C11.1867 4 12.3467 4.35189 13.3334 5.01118C14.3201 5.67047 15.0891 6.60754 15.5433 7.7039C15.9974 8.80026 16.1162 10.0067 15.8847 11.1705C15.6532 12.3344 15.0818 13.4035 14.2426 14.2426C13.4035 15.0818 12.3344 15.6532 11.1705 15.8847C10.0067 16.1162 8.80026 15.9974 7.7039 15.5433C6.60754 15.0891 5.67047 14.3201 5.01118 13.3334C4.35189 12.3467 4 11.1867 4 10C4 8.4087 4.63214 6.88258 5.75736 5.75736C6.88258 4.63214 8.4087 4 10 4Z" fill="#464255" />
                        </svg>
                    </a>
                    <div class="geex-content__header__searchform geex-content__header__popup">
                        <input type="text" id="searchInput" placeholder="Search" class="geex-content__header__btn" />
                        <i class="uil uil-search"></i>
                    </div>
                </li>
               
                <li class="geex-content__header__quickaction__item">
                    <a href="#" class="geex-content__header__quickaction__link">
                        <img class="user-img" src="<?= base_url('assets/img/avatar/user.svg') ?>" alt="user" />
                    </a>
                    <div class="geex-content__header__popup geex-content__header__popup--author">
                        <div class="geex-content__header__popup__header">
                            <div class="geex-content__header__popup__header__img">
                                <img src="<?= base_url('assets/img/avatar/user.svg') ?>" alt="user" />
                            </div>
                            <div class="geex-content__header__popup__header__content">
                                <h3 class="geex-content__header__popup__header__title">Michael Brown</h3>
                                <span class="geex-content__header__popup__header__subtitle">CEO, PixcelsThemes</span>
                            </div>
                        </div>
                        <div class="geex-content__header__popup__content">
                            <ul class="geex-content__header__popup__items">
                                <li class="geex-content__header__popup__item">
                                    <a class="geex-content__header__popup__link" href="#">
                                        <i class="uil uil-user"></i>
                                        Profile
                                    </a>
                                </li>
                                <li class="geex-content__header__popup__item">
                                    <a class="geex-content__header__popup__link" href="#">
                                        <i class="uil uil-cog"></i>
                                        Settings
                                    </a>
                                </li>
                                <li class="geex-content__header__popup__item">
                                    <a class="geex-content__header__popup__link" href="#">
                                        <i class="uil uil-dollar-alt"></i>
                                        Billing
                                    </a>
                                </li>
                                <li class="geex-content__header__popup__item">
                                    <a class="geex-content__header__popup__link" href="#">
                                        <i class="uil uil-users-alt"></i>
                                        Activity
                                    </a>
                                </li>
                                <li class="geex-content__header__popup__item">
                                    <a class="geex-content__header__popup__link" href="#">
                                        <i class="uil uil-bell"></i>
                                        Help
                                    </a>
                                </li>
                            </ul>
                        </div>
                        <div class="geex-content__header__popup__footer">
                            <a href="#" class="geex-content__header__popup__footer__link">
                                <i class="uil uil-arrow-up-left"></i>Logout
                            </a>
                        </div>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</div>