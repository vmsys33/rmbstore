<div class="geex-sidebar">
    <a href="#" class="geex-sidebar__close">
        <i class="uil uil-times"></i>
    </a>
    <div class="geex-sidebar__wrapper">
        <div class="geex-sidebar__header">
            <a href="<?= site_url('admin/dashboard') ?>" class="geex-sidebar__logo">
                <?php 
                $navicon = \App\Helpers\SettingsHelper::getNavicon();
                $storeName = \App\Helpers\SettingsHelper::getStoreName();
                ?>
                <?php if ($navicon): ?>
                    <img class="logo-lite" src="<?= base_url($navicon) ?>" alt="<?= esc($storeName) ?>" style="max-height: 40px;" />
                    <img class="logo-dark" src="<?= base_url($navicon) ?>" alt="<?= esc($storeName) ?>" style="max-height: 40px;" />
                <?php else: ?>
                    <span class="logo-text"><?= esc($storeName) ?></span>
                <?php endif; ?>
            </a>
        </div>
        <nav class="geex-sidebar__menu-wrapper">
            <ul class="geex-sidebar__menu">
                <li class="geex-sidebar__menu__item">
                    <a href="<?= site_url('admin/dashboard') ?>" class="geex-sidebar__menu__link">
                        <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <g clip-path="url(#clip0_1139_9707)">
                                <path d="M21.1943 8.31319L14.2413 1.35936C13.3808 0.501345 12.2152 0.0195312 11 0.0195312C9.78482 0.0195312 8.61921 0.501345 7.75868 1.35936L0.805761 8.31319C0.549484 8.56782 0.3463 8.8708 0.207987 9.20454C0.0696733 9.53829 -0.00101787 9.89617 1.10729e-05 10.2574V19.2564C1.10729e-05 19.9857 0.289742 20.6852 0.805467 21.2009C1.32119 21.7166 2.02067 22.0064 2.75001 22.0064H19.25C19.9794 22.0064 20.6788 21.7166 21.1946 21.2009C21.7103 20.6852 22 19.9857 22 19.2564V10.2574C22.001 9.89617 21.9303 9.53829 21.792 9.20454C21.6537 8.8708 21.4505 8.56782 21.1943 8.31319ZM13.75 20.173H8.25001V16.5669C8.25001 15.8375 8.53974 15.138 9.05547 14.6223C9.57119 14.1066 10.2707 13.8169 11 13.8169C11.7294 13.8169 12.4288 14.1066 12.9446 14.6223C13.4603 15.138 13.75 15.8375 13.75 16.5669V20.173ZM20.1667 19.2564C20.1667 19.4995 20.0701 19.7326 19.8982 19.9045C19.7263 20.0764 19.4931 20.173 19.25 20.173H15.5833V16.5669C15.5833 15.3513 15.1005 14.1855 14.2409 13.3259C13.3814 12.4664 12.2156 11.9835 11 11.9835C9.78444 11.9835 8.61865 12.4664 7.75911 13.3259C6.89956 14.1855 6.41668 15.3513 6.41668 16.5669V20.173H2.75001C2.5069 20.173 2.27374 20.0764 2.10183 19.9045C1.92992 19.7326 1.83334 19.4995 1.83334 19.2564V10.2574C1.83419 10.0145 1.93068 9.78168 2.10193 9.60935L9.05485 2.65827C9.57157 2.14396 10.271 1.85522 11 1.85522C11.7291 1.85522 12.4285 2.14396 12.9452 2.65827L19.8981 9.61211C20.0687 9.78375 20.1651 10.0155 20.1667 10.2574V19.2564Z" fill="#B9BBBD" />
                            </g>
                            <defs>
                                <clipPath id="clip0_1139_9707">
                                    <rect width="22" height="22" fill="white" />
                                </clipPath>
                            </defs>
                        </svg>
                        <span>Dashboard</span>
                    </a>
                </li>

                <li class="geex-sidebar__menu__item">
                                         <a href="<?= site_url('admin/products') ?>" class="geex-sidebar__menu__link">
                        <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <g clip-path="url(#clip0_1139_9714)">
                                <path d="M6.41667 0H3.66667C2.69421 0 1.76158 0.386308 1.07394 1.07394C0.386308 1.76158 0 2.69421 0 3.66667L0 6.41667C0 7.38913 0.386308 8.32176 1.07394 9.00939C1.76158 9.69702 2.69421 10.0833 3.66667 10.0833H6.41667C7.38913 10.0833 8.32176 9.69702 9.00939 9.00939C9.69702 8.32176 10.0833 7.38913 10.0833 6.41667V3.66667C10.0833 2.69421 9.69702 1.76158 9.00939 1.07394C8.32176 0.386308 7.38913 0 6.41667 0V0ZM8.25 6.41667C8.25 6.9029 8.05684 7.36921 7.71303 7.71303C7.36921 8.05684 6.9029 8.25 6.41667 8.25H3.66667C3.18044 8.25 2.71412 8.05684 2.3703 7.71303C2.02649 7.36921 1.83333 6.9029 1.83333 6.41667V3.66667C1.83333 3.18044 2.02649 2.71412 2.3703 2.3703C2.71412 2.02649 3.18044 1.83333 3.66667 1.83333H6.41667C6.9029 1.83333 7.36921 2.02649 7.71303 2.3703C8.05684 2.71412 8.25 3.18044 8.25 3.66667V6.41667Z" fill="#B9BBBD" />
                                <path d="M18.3327 0H15.5827C14.6102 0 13.6776 0.386309 12.99 1.07394C12.3023 1.76158 11.916 2.69421 11.916 3.66667V6.41667C11.916 7.38913 12.3023 8.32176 12.99 9.0094C13.6776 9.69703 14.6102 10.0833 15.5827 10.0833H18.3327C19.3051 10.0833 20.2378 9.69703 20.9254 9.0094C21.613 8.32176 21.9993 7.38913 21.9993 6.41667V3.66667C21.9993 2.69421 21.613 1.76158 20.9254 1.07394C20.2378 0.386309 19.3051 0 18.3327 0V0ZM20.166 6.41667C20.166 6.9029 19.9728 7.36922 19.629 7.71303C19.2852 8.05685 18.8189 8.25 18.3327 8.25H15.5827C15.0964 8.25 14.6301 8.05685 14.2863 7.71303C13.9425 7.36922 13.7493 6.9029 13.7493 6.41667V3.66667C13.7493 3.18044 13.9425 2.71412 14.2863 2.37031C14.6301 2.02649 15.0964 1.83333 15.5827 1.83333H18.3327C18.8189 1.83333 19.2852 2.02649 19.629 2.37031C19.9728 2.71412 20.166 3.18044 20.166 3.66667V6.41667Z" fill="#B9BBBD" />
                                <path d="M6.41667 11.9167H3.66667C2.69421 11.9167 1.76158 12.3031 1.07394 12.9907C0.386308 13.6783 0 14.611 0 15.5834L0 18.3334C0 19.3059 0.386308 20.2385 1.07394 20.9262C1.76158 21.6138 2.69421 22.0001 3.66667 22.0001H6.41667C7.38913 22.0001 8.32176 21.6138 9.00939 20.9262C9.69702 20.2385 10.0833 19.3059 10.0833 18.3334V15.5834C10.0833 14.611 9.69702 13.6783 9.00939 12.9907C8.32176 12.3031 7.38913 11.9167 6.41667 11.9167ZM8.25 18.3334C8.25 18.8197 8.05684 19.286 7.71303 19.6298C7.36921 19.9736 6.9029 20.1668 6.41667 20.1668H3.66667C3.18044 20.1668 2.71412 19.9736 2.3703 19.6298C2.02649 19.286 1.83333 18.8197 1.83333 18.3334V15.5834C1.83333 15.0972 2.02649 14.6309 2.3703 14.2871C2.71412 13.9432 3.18044 13.7501 3.66667 13.7501H6.41667C6.9029 13.7501 7.36921 13.9432 7.71303 14.2871C8.05684 14.6309 8.25 15.0972 8.25 15.5834V18.3334Z" fill="#B9BBBD" />
                                <path d="M18.3327 11.9167H15.5827C14.6102 11.9167 13.6776 12.3031 12.99 12.9907C12.3023 13.6783 11.916 14.611 11.916 15.5834V18.3334C11.916 19.3059 12.3023 20.2385 12.99 20.9262C13.6776 21.6138 14.6102 22.0001 15.5827 22.0001H18.3327C19.3051 22.0001 20.2378 21.6138 20.9254 20.9262C21.613 20.2385 21.9993 19.3059 21.9993 18.3334V15.5834C21.9993 14.611 21.613 13.6783 20.9254 12.9907C20.2378 12.3031 19.3051 11.9167 18.3327 11.9167ZM20.166 18.3334C20.166 18.8197 19.9728 19.286 19.629 19.6298C19.2852 19.9736 18.8189 20.1668 18.3327 20.1668H15.5827C15.0964 20.1668 14.6301 19.9736 14.2863 19.6298C13.9425 19.286 13.7493 18.8197 13.7493 18.3334V15.5834C13.7493 15.0972 13.9425 14.6309 14.2863 14.2871C14.6301 13.9432 15.0964 13.7501 15.5827 13.7501H18.3327C18.8189 13.7501 19.2852 13.9432 19.629 14.2871C19.9728 14.6309 20.166 15.0972 20.166 15.5834V18.3334Z" fill="#B9BBBD" />
                            </g>
                            <defs>
                                <clipPath id="clip0_1139_9714">
                                    <rect width="22" height="22" fill="white" />
                                </clipPath>
                            </defs>
                        </svg>
                        <span>Products</span>
                    </a>
                </li>

                <li class="geex-sidebar__menu__item">
                                         <a href="<?= site_url('admin/categories') ?>" class="geex-sidebar__menu__link">
                        <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <g clip-path="url(#clip0_1139_9715)">
                                <path d="M11 0C4.925 0 0 4.925 0 11C0 17.075 4.925 22 11 22C17.075 22 22 17.075 22 11C22 4.925 17.075 0 11 0ZM11 20C6.03 20 2 15.97 2 11C2 6.03 6.03 2 11 2C15.97 2 20 6.03 20 11C20 15.97 15.97 20 11 20Z" fill="#B9BBBD"/>
                                <path d="M11 4C7.14 4 4 7.14 4 11C4 14.86 7.14 18 11 18C14.86 18 18 14.86 18 11C18 7.14 14.86 4 11 4ZM11 16C8.24 16 6 13.76 6 11C6 8.24 8.24 6 11 6C13.76 6 16 8.24 16 11C16 13.76 13.76 16 11 16Z" fill="#B9BBBD"/>
                            </g>
                            <defs>
                                <clipPath id="clip0_1139_9715">
                                    <rect width="22" height="22" fill="white" />
                                </clipPath>
                            </defs>
                        </svg>
                        <span>Categories</span>
                    </a>
                </li>

                <li class="geex-sidebar__menu__item">
                                         <a href="<?= site_url('admin/sliders') ?>" class="geex-sidebar__menu__link">
                        <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <g clip-path="url(#clip0_1139_9718)">
                                <path d="M19 3H5C3.9 3 3 3.9 3 5V19C3 20.1 3.9 21 5 21H19C20.1 21 21 20.1 21 19V5C21 3.9 20.1 3 19 3ZM19 19H5V5H19V19Z" fill="#B9BBBD"/>
                                <path d="M14 7H8V9H14V7Z" fill="#B9BBBD"/>
                                <path d="M16 11H8V13H16V11Z" fill="#B9BBBD"/>
                                <path d="M12 15H8V17H12V15Z" fill="#B9BBBD"/>
                            </g>
                            <defs>
                                <clipPath id="clip0_1139_9718">
                                    <rect width="22" height="22" fill="white" />
                                </clipPath>
                            </defs>
                        </svg>
                        <span>Sliders</span>
                    </a>
                </li>

                <li class="geex-sidebar__menu__item">
                                         <a href="<?= site_url('admin/pos') ?>" class="geex-sidebar__menu__link">
                        <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <g clip-path="url(#clip0_1139_9719)">
                                <path d="M20 4H4C2.89 4 2 4.89 2 6V18C2 19.11 2.89 20 4 20H20C21.11 20 22 19.11 22 18V6C22 4.89 21.11 4 20 4ZM20 18H4V6H20V18Z" fill="#B9BBBD"/>
                                <path d="M6 8H16V10H6V8Z" fill="#B9BBBD"/>
                                <path d="M6 12H14V14H6V12Z" fill="#B9BBBD"/>
                                <path d="M6 16H12V18H6V16Z" fill="#B9BBBD"/>
                            </g>
                            <defs>
                                <clipPath id="clip0_1139_9719">
                                    <rect width="22" height="22" fill="white" />
                                </clipPath>
                            </defs>
                        </svg>
                        <span>Point of Sale</span>
                    </a>
                </li>

                <li class="geex-sidebar__menu__item">
                    <a href="<?= site_url('admin/sales-summary') ?>" class="geex-sidebar__menu__link">
                        <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <g clip-path="url(#clip0_1139_9720)">
                                <path d="M19 3H5C3.9 3 3 3.9 3 5V19C3 20.1 3.9 21 5 21H19C20.1 21 21 20.1 21 19V5C21 3.9 20.1 3 19 3ZM19 19H5V5H19V19Z" fill="#B9BBBD"/>
                                <path d="M7 7H17V9H7V7Z" fill="#B9BBBD"/>
                                <path d="M7 11H17V13H7V11Z" fill="#B9BBBD"/>
                                <path d="M7 15H13V17H7V15Z" fill="#B9BBBD"/>
                            </g>
                            <defs>
                                <clipPath id="clip0_1139_9720">
                                    <rect width="22" height="22" fill="white" />
                                </clipPath>
                            </defs>
                        </svg>
                        <span>Sales Summary</span>
                    </a>
                </li>



                <li class="geex-sidebar__menu__item">
                                         <a href="<?= site_url('admin/users') ?>" class="geex-sidebar__menu__link">
                        <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <g clip-path="url(#clip0_1139_9716)">
                                <path d="M11 0C4.925 0 0 4.925 0 11C0 17.075 4.925 22 11 22C17.075 22 22 17.075 22 11C22 4.925 17.075 0 11 0ZM11 20C6.03 20 2 15.97 2 11C2 6.03 6.03 2 11 2C15.97 2 20 6.03 20 11C20 15.97 15.97 20 11 20Z" fill="#B9BBBD"/>
                                <path d="M11 6C9.34 6 8 7.34 8 9C8 10.66 9.34 12 11 12C12.66 12 14 10.66 14 9C14 7.34 12.66 6 11 6ZM11 10C10.45 10 10 9.55 10 9C10 8.45 10.45 8 11 8C11.55 8 12 8.45 12 9C12 9.55 11.55 10 11 10Z" fill="#B9BBBD"/>
                                <path d="M11 13C8.33 13 4 14.34 4 17V20H18V17C18 14.34 13.67 13 11 13ZM16 18H6V17.01C6.2 16.29 9.3 15 11 15C12.7 15 15.8 16.29 16 17V18Z" fill="#B9BBBD"/>
                            </g>
                            <defs>
                                <clipPath id="clip0_1139_9716">
                                    <rect width="22" height="22" fill="white" />
                                </clipPath>
                            </defs>
                        </svg>
                        <span>Users</span>
                    </a>
                </li>

                <li class="geex-sidebar__menu__item">
                                         <a href="<?= site_url('admin/settings') ?>" class="geex-sidebar__menu__link">
                        <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <g clip-path="url(#clip0_1139_9717)">
                                <path d="M19.14 12.94C18.5 12.94 17.96 12.4 17.96 11.76C17.96 11.12 18.5 10.58 19.14 10.58C19.78 10.58 20.32 11.12 20.32 11.76C20.32 12.4 19.78 12.94 19.14 12.94Z" fill="#B9BBBD"/>
                                <path d="M11 12.94C10.36 12.94 9.82 12.4 9.82 11.76C9.82 11.12 10.36 10.58 11 10.58C11.64 10.58 12.18 11.12 12.18 11.76C12.18 12.4 11.64 12.94 11 12.94Z" fill="#B9BBBD"/>
                                <path d="M2.86 12.94C2.22 12.94 1.68 12.4 1.68 11.76C1.68 11.12 2.22 10.58 2.86 10.58C3.5 10.58 4.04 11.12 4.04 11.76C4.04 12.4 3.5 12.94 2.86 12.94Z" fill="#B9BBBD"/>
                            </g>
                            <defs>
                                <clipPath id="clip0_1139_9717">
                                    <rect width="22" height="22" fill="white" />
                                </clipPath>
                            </defs>
                        </svg>
                        <span>Settings</span>
                    </a>
                </li>


            </ul>
        </nav>
        <div class="geex-sidebar__footer">
            <span class="geex-sidebar__footer__title"><?= $storeName ?> Dashboard</span>
            <p class="geex-sidebar__footer__copyright">© 2025 All Rights Reserved</p>
            <p class="geex-sidebar__footer__author"><?= $storeName ?> <span class="heart-icon">♥</span> by <a href="">VanBaltazar</a></p>
        </div>
    </div>
</div>