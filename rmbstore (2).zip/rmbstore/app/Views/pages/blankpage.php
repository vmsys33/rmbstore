
<?= $this->extend('layout/layout2'); ?>

<?= $this->section('content'); ?> 

		<div class="geex-content__section geex-content__blank">
			<div class="geex-content__error__wrapper">
				<!-- PAGE CONTENT START  -->
				<div class="geex-content__error__content">
				</div>
				<!-- PAGE CONTENT END -->
			</div>
		</div>

<?= $this->endSection(); ?>