<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chatbot Q&A Management - RMB Store</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <style>
        .container { margin-top: 20px; }
        .card { margin-bottom: 20px; }
        .btn-small { margin: 5px; }
        .search-box { margin-bottom: 20px; }
        .qa-item { border: 1px solid #ddd; padding: 15px; margin: 10px 0; border-radius: 5px; }
        .qa-question { font-weight: bold; color: #1976d2; }
        .qa-answer { margin: 10px 0; }
        .qa-meta { font-size: 12px; color: #666; }
        .priority-high { border-left: 4px solid #f44336; }
        .priority-medium { border-left: 4px solid #ff9800; }
        .priority-low { border-left: 4px solid #4caf50; }
    </style>
</head>
<body>
    <div class="container">
        <h2>🤖 Chatbot Q&A Management</h2>
        
        <!-- Add New Q&A Form -->
        <div class="card">
            <div class="card-content">
                <span class="card-title">Add New Q&A</span>
                <form id="addQAForm">
                    <div class="row">
                        <div class="input-field col s12">
                            <input id="question" type="text" required>
                            <label for="question">Question</label>
                        </div>
                    </div>
                    <div class="row">
                        <div class="input-field col s12">
                            <textarea id="answer" class="materialize-textarea" required></textarea>
                            <label for="answer">Answer</label>
                        </div>
                    </div>
                    <div class="row">
                        <div class="input-field col s6">
                            <input id="category" type="text" value="general">
                            <label for="category">Category</label>
                        </div>
                        <div class="input-field col s6">
                            <input id="keywords" type="text" placeholder="keyword1,keyword2,keyword3">
                            <label for="keywords">Keywords (comma separated)</label>
                        </div>
                    </div>
                    <div class="row">
                        <div class="input-field col s6">
                            <select id="priority">
                                <option value="1">Low Priority</option>
                                <option value="2" selected>Medium Priority</option>
                                <option value="3">High Priority</option>
                            </select>
                            <label>Priority</label>
                        </div>
                        <div class="input-field col s6">
                            <select id="status">
                                <option value="active" selected>Active</option>
                                <option value="inactive">Inactive</option>
                            </select>
                            <label>Status</label>
                        </div>
                    </div>
                    <button class="btn waves-effect waves-light" type="submit">
                        <i class="material-icons left">add</i>Add Q&A
                    </button>
                </form>
            </div>
        </div>

        <!-- Search and Filter -->
        <div class="card">
            <div class="card-content">
                <span class="card-title">Search & Filter</span>
                <div class="row">
                    <div class="input-field col s8">
                        <input id="searchInput" type="text" placeholder="Search questions, answers, or keywords...">
                        <label for="searchInput">Search</label>
                    </div>
                    <div class="input-field col s4">
                        <select id="categoryFilter">
                            <option value="">All Categories</option>
                            <option value="general">General</option>
                            <option value="business">Business</option>
                            <option value="products">Products</option>
                            <option value="shipping">Shipping</option>
                            <option value="returns">Returns</option>
                            <option value="contact">Contact</option>
                            <option value="quality">Quality</option>
                            <option value="sizing">Sizing</option>
                            <option value="pricing">Pricing</option>
                        </select>
                        <label>Filter by Category</label>
                    </div>
                </div>
            </div>
        </div>

        <!-- Q&A List -->
        <div class="card">
            <div class="card-content">
                <span class="card-title">Q&A Entries (<span id="qaCount">0</span>)</span>
                <div id="qaList">
                    <!-- Q&A items will be loaded here -->
                </div>
            </div>
        </div>
    </div>

    <!-- Edit Q&A Modal -->
    <div id="editModal" class="modal">
        <div class="modal-content">
            <h4>Edit Q&A</h4>
            <form id="editQAForm">
                <input type="hidden" id="editId">
                <div class="row">
                    <div class="input-field col s12">
                        <input id="editQuestion" type="text" required>
                        <label for="editQuestion">Question</label>
                    </div>
                </div>
                <div class="row">
                    <div class="input-field col s12">
                        <textarea id="editAnswer" class="materialize-textarea" required></textarea>
                        <label for="editAnswer">Answer</label>
                    </div>
                </div>
                <div class="row">
                    <div class="input-field col s6">
                        <input id="editCategory" type="text">
                        <label for="editCategory">Category</label>
                    </div>
                    <div class="input-field col s6">
                        <input id="editKeywords" type="text">
                        <label for="editKeywords">Keywords</label>
                    </div>
                </div>
                <div class="row">
                    <div class="input-field col s6">
                        <select id="editPriority">
                            <option value="1">Low Priority</option>
                            <option value="2">Medium Priority</option>
                            <option value="3">High Priority</option>
                        </select>
                        <label>Priority</label>
                    </div>
                    <div class="input-field col s6">
                        <select id="editStatus">
                            <option value="active">Active</option>
                            <option value="inactive">Inactive</option>
                        </select>
                        <label>Status</label>
                    </div>
                </div>
            </form>
        </div>
        <div class="modal-footer">
            <button class="btn waves-effect waves-light" id="saveEditBtn">
                <i class="material-icons left">save</i>Save Changes
            </button>
            <button class="modal-close btn-flat">Cancel</button>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Initialize Materialize components
            M.AutoInit();
            
            // Load Q&A data
            loadQA();
            
            // Event listeners
            document.getElementById('addQAForm').addEventListener('submit', addQA);
            document.getElementById('searchInput').addEventListener('input', filterQA);
            document.getElementById('categoryFilter').addEventListener('change', filterQA);
            document.getElementById('saveEditBtn').addEventListener('click', saveEdit);
        });

        // Load Q&A data
        async function loadQA() {
            try {
                const response = await fetch('/chatbot/getQA');
                if (response.ok) {
                    const result = await response.json();
                    if (result.status === 'success') {
                        displayQA(result.data);
                    }
                }
            } catch (error) {
                console.error('Failed to load Q&A:', error);
            }
        }

        // Display Q&A list
        function displayQA(qaList) {
            const container = document.getElementById('qaList');
            const count = document.getElementById('qaCount');
            
            count.textContent = qaList.length;
            
            if (qaList.length === 0) {
                container.innerHTML = '<p>No Q&A entries found.</p>';
                return;
            }
            
            container.innerHTML = qaList.map(qa => `
                <div class="qa-item priority-${qa.priority === 3 ? 'high' : qa.priority === 2 ? 'medium' : 'low'}" data-id="${qa.id}">
                    <div class="qa-question">${qa.question}</div>
                    <div class="qa-answer">${qa.answer.replace(/\n/g, '<br>')}</div>
                    <div class="qa-meta">
                        <span class="badge blue">${qa.category}</span>
                        <span class="badge ${qa.priority === 3 ? 'red' : qa.priority === 2 ? 'orange' : 'green'}">Priority ${qa.priority}</span>
                        <span class="badge ${qa.status === 'active' ? 'green' : 'grey'}">${qa.status}</span>
                        <span class="badge grey">${qa.keywords || 'No keywords'}</span>
                    </div>
                    <div class="right-align">
                        <button class="btn-small waves-effect waves-light blue" onclick="editQA(${qa.id})">
                            <i class="material-icons">edit</i>
                        </button>
                        <button class="btn-small waves-effect waves-light red" onclick="deleteQA(${qa.id})">
                            <i class="material-icons">delete</i>
                        </button>
                    </div>
                </div>
            `).join('');
        }

        // Add new Q&A
        async function addQA(e) {
            e.preventDefault();
            
            const formData = {
                question: document.getElementById('question').value,
                answer: document.getElementById('answer').value,
                category: document.getElementById('category').value,
                keywords: document.getElementById('keywords').value,
                priority: document.getElementById('priority').value,
                status: document.getElementById('status').value
            };
            
            try {
                // For now, we'll just add to the display
                // In a real implementation, you'd send this to your backend
                const newQA = {
                    id: Date.now(),
                    ...formData,
                    created_at: new Date().toISOString()
                };
                
                // Reload the Q&A list
                loadQA();
                
                // Reset form
                document.getElementById('addQAForm').reset();
                M.updateTextFields();
                
                M.toast({html: 'Q&A added successfully!'});
            } catch (error) {
                M.toast({html: 'Failed to add Q&A: ' + error.message});
            }
        }

        // Filter Q&A
        function filterQA() {
            const searchTerm = document.getElementById('searchInput').value.toLowerCase();
            const categoryFilter = document.getElementById('categoryFilter').value;
            
            const qaItems = document.querySelectorAll('.qa-item');
            
            qaItems.forEach(item => {
                const question = item.querySelector('.qa-question').textContent.toLowerCase();
                const answer = item.querySelector('.qa-answer').textContent.toLowerCase();
                const category = item.querySelector('.badge.blue').textContent;
                
                const matchesSearch = question.includes(searchTerm) || answer.includes(searchTerm);
                const matchesCategory = !categoryFilter || category === categoryFilter;
                
                item.style.display = matchesSearch && matchesCategory ? 'block' : 'none';
            });
        }

        // Edit Q&A
        function editQA(id) {
            // Find the Q&A item
            const qaItem = document.querySelector(`[data-id="${id}"]`);
            if (!qaItem) return;
            
            // Populate edit form
            document.getElementById('editId').value = id;
            document.getElementById('editQuestion').value = qaItem.querySelector('.qa-question').textContent;
            document.getElementById('editAnswer').value = qaItem.querySelector('.qa-answer').textContent.replace(/<br>/g, '\n');
            
            // Open modal
            const modal = M.Modal.getInstance(document.getElementById('editModal'));
            modal.open();
        }

        // Save edit
        async function saveEdit() {
            const id = document.getElementById('editId').value;
            const formData = {
                question: document.getElementById('editQuestion').value,
                answer: document.getElementById('editAnswer').value,
                category: document.getElementById('editCategory').value,
                keywords: document.getElementById('editKeywords').value,
                priority: document.getElementById('editPriority').value,
                status: document.getElementById('editStatus').value
            };
            
            try {
                // In a real implementation, you'd send this to your backend
                M.toast({html: 'Q&A updated successfully!'});
                
                // Close modal and reload
                const modal = M.Modal.getInstance(document.getElementById('editModal'));
                modal.close();
                loadQA();
            } catch (error) {
                M.toast({html: 'Failed to update Q&A: ' + error.message});
            }
        }

        // Delete Q&A
        function deleteQA(id) {
            if (confirm('Are you sure you want to delete this Q&A entry?')) {
                // In a real implementation, you'd send this to your backend
                M.toast({html: 'Q&A deleted successfully!'});
                loadQA();
            }
        }
    </script>
</body>
</html>
