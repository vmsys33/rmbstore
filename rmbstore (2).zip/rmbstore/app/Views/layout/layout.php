<!doctype html>
<html lang="en" dir="ltr">

<?= $this->include('partials/head') ?> 

<body class="geex-dashboard">

    <?= $this->include('partials/header') ?> 

    <main class="geex-main-content">

        <?= $this->include('partials/sidebar') ?> 

        <?= $this->include('partials/customizer') ?> 
        

        <div class="geex-content">
            <?= $this->include('partials/contentHeader') ?> 
                <?= $this->renderSection('content') ?> <!-- Main content from the page -->

        </div>
    </main>

    <!-- JAVASCRIPTS START -->
    <script src="<?= base_url('assets/vendor/js/jquery/jquery-3.5.1.min.js') ?>"></script>
	<script src="<?= base_url('assets/vendor/js/jquery/jquery-ui.js') ?>"></script>
	<script src="<?= base_url('assets/vendor/js/bootstrap/bootstrap.min.js') ?>"></script>

    <?= $this->renderSection('custom_scripts') ?> 
    
    <script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/apexcharts@3.27.0/dist/apexcharts.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/dragula/3.6.6/dragula.min.js" referrerpolicy="origin"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="<?= base_url('assets/js/main.js?v=' . time()) ?>"></script>

    <!-- Chatbot Widget -->
    <div class="chatbot-widget" id="chatbotWidget">
        <!-- Chat Button -->
        <div class="chat-button" id="chatButton">
            <i class="fas fa-comments"></i>
            <span class="notification-badge" id="notificationBadge">1</span>
        </div>
        
        <!-- Chat Window -->
        <div class="chat-window" id="chatWindow">
            <!-- Chat Header -->
            <div class="chat-header">
                <div class="chat-header-info">
                    <div class="chat-avatar">
                        <i class="fas fa-robot"></i>
                    </div>
                    <div class="chat-title">
                        <h4>AI Assistant</h4>
                        <span class="status">Online</span>
                    </div>
                </div>
                <div class="chat-actions">
                    <button class="minimize-btn" id="minimizeBtn">
                        <i class="fas fa-minus"></i>
                    </button>
                    <button class="close-btn" id="closeBtn">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
            </div>
            
            <!-- Chat Messages -->
            <div class="chat-messages" id="chatMessages">
                <!-- Welcome Message -->
                <div class="message bot-message">
                    <div class="message-content">
                        <p>👋 Hello! I'm your AI assistant. How can I help you today?</p>
                        <span class="message-time">Just now</span>
                    </div>
                </div>
                
                <!-- Quick Reply Buttons -->
                <div class="quick-replies" id="quickReplies">
                    <button class="quick-reply-btn" data-message="Tell me about your products">Products</button>
                    <button class="quick-reply-btn" data-message="How can I contact support?">Support</button>
                    <button class="quick-reply-btn" data-message="What are your business hours?">Hours</button>
                </div>
            </div>
            
            <!-- Chat Input -->
            <div class="chat-input-container">
                <div class="chat-input-wrapper">
                    <input type="text" id="chatInput" placeholder="Type your message..." maxlength="500">
                    <button class="send-btn" id="sendBtn">
                        <i class="fas fa-paper-plane"></i>
                    </button>
                </div>
                <div class="typing-indicator" id="typingIndicator">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </div>
        </div>
    </div>

    <!-- Chatbot JavaScript -->
    <script src="<?= base_url('assets/frontend/js/chatbot.js') ?>"></script>

    <!-- JAVASCRIPTS END -->
</body>

</html>