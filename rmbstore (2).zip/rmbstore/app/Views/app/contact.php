<?= $this->extend('layout/layout'); ?>

<?= $this->section('content'); ?> 

	<div class="geex-content__wrapper">
		<div class="geex-content__section-wrapper">
			<div class="geex-content__section geex-content__section--transparent geex-content__todo">
				<div class="geex-content__todo__content tab-content custom-al" id="geex-todo-task-content">
					<div class="tab-pane fade show active" id="geex-todo-task-content-important">
						<div class="geex-content__todo__header custom-al">
							<div class="geex-content__todo__header__title">
								<button class="geex-btn geex-btn--primary geex-btn__add-modal"><i class="uil-plus"></i> New Contact</button>
							</div>
							<ul class="nav nav-tabs geex-todo-tab geex-content__todo__header__filter" id="geex-todo-tab" role="tablist">
								<li>
									<button class="geex-btn geex-btn--primary-transparent">
										Favourites (20)
										<i class="uil uil-heart"></i>
									</button>
								</li>
								<li class="geex-content__todo__header__filter__sortby">
									<select>
										<option value="newest">Newest Contacts</option>
										<option value="oldest">Oldest</option>
										<option value="name">Name</option>
									</select>
									<i class="uil-angle-down"></i>
								</li>
								<li class="nav-item" role="presentation">
									<a href="#" id="todo_list_tab" class="" data-bs-toggle="tab" data-bs-target="#todo_list_content" type="button" role="tab" aria-controls="todo_list_content" aria-selected="false">
										<i class="uil-bars"></i>
									</a>
								</li>
								<li class="nav-item" role="presentation">
									<a href="#" id="todo_grid_tab" class="active" data-bs-toggle="tab" data-bs-target="#todo_grid_content" type="button" role="tab" aria-controls="todo_grid_contant" aria-selected="false">
										<i class="uil-apps"></i>
									</a>
								</li>
							</ul>
						</div>
						<div class="tab-content geex-transaction-content">
							<div class="tab-pane fade  " id="todo_list_content" role="tabpanel" aria-labelledby="todo_list_tab">

								<div class="geex-content__section geex-content__form table-responsive">


									<table class="table-reviews-geex-1">
										<thead>
											<tr style="width: 100%;">
												<th style="width: 20%;">Name</th>
												<th style="width: 20%;">Designation</th>
												<th style="width: 20%;">Company</th>
												<th style="width: 20%;">Phone</th>
												<th style="width: 20%;">Email</th>
											</tr>
										</thead>
										<tbody class="">
											<tr>
												<td>
													<div class="author-area">
														<div class="profile-picture">
															<img src="<?= base_url('assets/img/contact/01.png') ?>" alt="reviews">
														</div>
														<p>david millar</p>
													</div>
												</td>
												<td>
													<span class="designation">(CEO)*</span>
												</td>
												<td>
													<span class="name">ReacThemes</span>
												</td>
												<td><a href="tel:+4733378901">+8801265648289</a></td>
												<td><a href="mailto:webmaster@example.com">millar@mail.com</a></td>
											</tr>
											<tr>
												<td>
													<div class="author-area">
														<div class="profile-picture">
															<img src="<?= base_url('assets/img/contact/02.png') ?>" alt="reviews">
														</div>
														<p>Brian Pfeffer</p>
													</div>
												</td>
												<td>
													<span class="designation">Senior Developer</span>
												</td>
												<td>
													<span class="name">ThemeWant</span>
												</td>
												<td><a href="tel:+4733378901">+880121238789</a></td>
												<td><a href="mailto:webmaster@example.com">Brian@mail.com</a></td>
											</tr>
											<tr>
												<td>
													<div class="author-area">
														<div class="profile-picture">
															<img src="<?= base_url('assets/img/contact/03.png') ?>" alt="reviews">
														</div>
														<p>Tamim Iqbal</p>
													</div>
												</td>
												<td>
													<span class="designation">Developer</span>
												</td>
												<td>
													<span class="name">ReacThemes</span>
												</td>
												<td><a href="tel:+4733378901">+880125968789</a></td>
												<td><a href="mailto:webmaster@example.com">Tamim@mail.com</a></td>
											</tr>
											<tr>
												<td>
													<div class="author-area">
														<div class="profile-picture">
															<img src="<?= base_url('assets/img/contact/04.png') ?>" alt="reviews">
														</div>
														<p>Mehadi Meraj</p>
													</div>
												</td>
												<td>
													<span class="designation">Senior Designer</span>
												</td>
												<td>
													<span class="name">ThemeWant</span>
												</td>
												<td><a href="tel:+4733378901">+880123235419</a></td>
												<td><a href="mailto:webmaster@example.com">Mehadi@mail.com</a></td>
											</tr>
											<tr>
												<td>
													<div class="author-area">
														<div class="profile-picture">
															<img src="<?= base_url('assets/img/contact/05.png') ?>" alt="reviews">
														</div>
														<p>Sakib al Hasan</p>
													</div>
												</td>
												<td>
													<span class="designation">Designer</span>
												</td>
												<td>
													<span class="name">ReacThemes</span>
												</td>
												<td><a href="tel:+4733378901">+880123464239</a></td>
												<td><a href="mailto:webmaster@example.com">Sakib@mail.com</a></td>
											</tr>
											<tr>
												<td>
													<div class="author-area">
														<div class="profile-picture">
															<img src="<?= base_url('assets/img/contact/06.png') ?>" alt="reviews">
														</div>
														<p>MR.John Lee</p>
													</div>
												</td>
												<td>
													<span class="designation">Content Writer</span>
												</td>
												<td>
													<span class="name">ThemeWant</span>
												</td>
												<td><a href="tel:+4733378901">+880123456889</a></td>
												<td><a href="mailto:webmaster@example.com">John@mail.com</a></td>
											</tr>
											<tr>
												<td>
													<div class="author-area">
														<div class="profile-picture">
															<img src="<?= base_url('assets/img/contact/07.png') ?>" alt="reviews">
														</div>
														<p>Christopher</p>
													</div>
												</td>
												<td>
													<span class="designation">(COO)</span>
												</td>
												<td>
													<span class="name">ReacThemes</span>
												</td>
												<td><a href="tel:+4733378901">+880123468789</a></td>
												<td><a href="mailto:webmaster@example.com">Christopher@mail.com</a></td>
											</tr>
											<tr>
												<td>
													<div class="author-area">
														<div class="profile-picture">
															<img src="<?= base_url('assets/img/contact/08.png') ?>" alt="reviews">
														</div>
														<p>MR.Christopher</p>
													</div>
												</td>
												<td>
													<span class="designation">Central Usability Officer</span>
												</td>
												<td>
													<span class="name">ThemeWant</span>
												</td>
												<td><a href="tel:+4733378901">+880123468789</a></td>
												<td><a href="mailto:webmaster@example.com">Christopher@mail.com</a></td>
											</tr>
										</tbody>
									</table>
								</div>

							</div>
							<div class="tab-pane fade show active" id="todo_grid_content" role="tabpanel" aria-labelledby="todo_grid_tab">

								<div class="row g-40">
									<div class="col-xxl-3 col-xl-4 col-lg-4 col-md-6 col-sm-12">
										<!-- single contact grid area start -->
										<div class="single-contact-grid-area">
											<div class="top-area">
												<div class="avatar">
													<img src="<?= base_url('assets/img/contact/01.png') ?>" alt="">
												</div>
												<div class="action-area">
													<div class="single">
														<i class="uil uil-heart"></i>
													</div>
													<div class="single geex-content__chat__header__filter__btn">
														<i class="uil uil-ellipsis-v"></i>
													</div>

													<div class="geex-content__chat__header__filter__content">
														<a class="dropdown-item" href="#">view</a>
														<a class="dropdown-item" href="#">Edit</a>
														<a class="dropdown-item" href="#">Details</a>
													</div>
												</div>
											</div>
											<div class="details-area">
												<h4 class="name">Ahmed Leffler</h4>
												<span class="designation">Central Usability Officer</span>
												<div class="contact-wrapper">
													<a href="#" class="single-contact">
														<i class="uil uil-bag"></i>
														<p>Highspeed Studios</p>
													</a>
													<a href="#" class="single-contact">
														<i class="uil uil-phone"></i>
														<p>+012 345 689</p>
													</a>
													<a href="#" class="single-contact">
														<i class="uil uil-envelope"></i>
														<p>tamara@mail.com</p>
													</a>
												</div>
											</div>
										</div>
										<!-- single contact grid area end -->
									</div>
									<div class="col-xxl-3 col-xl-4 col-lg-4 col-md-6 col-sm-12">
										<!-- single contact grid area start -->
										<div class="single-contact-grid-area">
											<div class="top-area">
												<div class="avatar">
													<img src="<?= base_url('assets/img/contact/02.png') ?>" alt="avatar">
												</div>
												<div class="action-area">
													<div class="single">
														<i class="uil uil-heart"></i>
													</div>
													<div class="single geex-content__chat__header__filter__btn">
														<i class="uil uil-ellipsis-v"></i>
													</div>

													<div class="geex-content__chat__header__filter__content">
														<a class="dropdown-item" href="#">view</a>
														<a class="dropdown-item" href="#">Edit</a>
														<a class="dropdown-item" href="#">Details</a>
													</div>
												</div>
											</div>
											<div class="details-area">
												<h4 class="name">Brian Pfeffer</h4>
												<span class="designation">Chief Tactics Supervisor</span>
												<div class="contact-wrapper">
													<a href="#" class="single-contact">
														<i class="uil uil-bag"></i>
														<p>Highspeed Studios</p>
													</a>
													<a href="#" class="single-contact">
														<i class="uil uil-phone"></i>
														<p>+012 345 689</p>
													</a>
													<a href="#" class="single-contact">
														<i class="uil uil-envelope"></i>
														<p>tamara@mail.com</p>
													</a>
												</div>
											</div>
										</div>
										<!-- single contact grid area end -->
									</div>
									<div class="col-xxl-3 col-xl-4 col-lg-4 col-md-6 col-sm-12">
										<!-- single contact grid area start -->
										<div class="single-contact-grid-area">
											<div class="top-area">
												<div class="avatar">
													<img src="<?= base_url('assets/img/contact/03.png') ?>" alt="">
												</div>
												<div class="action-area">
													<div class="single">
														<i class="uil uil-heart"></i>
													</div>
													<div class="single geex-content__chat__header__filter__btn">
														<i class="uil uil-ellipsis-v"></i>
													</div>

													<div class="geex-content__chat__header__filter__content">
														<a class="dropdown-item" href="#">view</a>
														<a class="dropdown-item" href="#">Edit</a>
														<a class="dropdown-item" href="#">Details</a>
													</div>
												</div>
											</div>
											<div class="details-area">
												<h4 class="name">Crhistine Zboncak</h4>
												<span class="designation">UI Designer</span>
												<div class="contact-wrapper">
													<a href="#" class="single-contact">
														<i class="uil uil-bag"></i>
														<p>Highspeed Studios</p>
													</a>
													<a href="#" class="single-contact">
														<i class="uil uil-phone"></i>
														<p>+012 345 689</p>
													</a>
													<a href="#" class="single-contact">
														<i class="uil uil-envelope"></i>
														<p>tamara@mail.com</p>
													</a>
												</div>
											</div>
										</div>
										<!-- single contact grid area end -->
									</div>
									<div class="col-xxl-3 col-xl-4 col-lg-4 col-md-6 col-sm-12">
										<!-- single contact grid area start -->
										<div class="single-contact-grid-area">
											<div class="top-area">
												<div class="avatar">
													<img src="<?= base_url('assets/img/contact/04.png') ?>" alt="">
												</div>
												<div class="action-area">
													<div class="single">
														<i class="uil uil-heart"></i>
													</div>
													<div class="single geex-content__chat__header__filter__btn">
														<i class="uil uil-ellipsis-v"></i>
													</div>

													<div class="geex-content__chat__header__filter__content">
														<a class="dropdown-item" href="#">view</a>
														<a class="dropdown-item" href="#">Edit</a>
														<a class="dropdown-item" href="#">Details</a>
													</div>
												</div>
											</div>
											<div class="details-area">
												<h4 class="name">David Koelpin</h4>
												<span class="designation">District Mobility Designer</span>
												<div class="contact-wrapper">
													<a href="#" class="single-contact">
														<i class="uil uil-bag"></i>
														<p>Highspeed Studios</p>
													</a>
													<a href="#" class="single-contact">
														<i class="uil uil-phone"></i>
														<p>+012 345 689</p>
													</a>
													<a href="#" class="single-contact">
														<i class="uil uil-envelope"></i>
														<p>tamara@mail.com</p>
													</a>
												</div>
											</div>
										</div>
										<!-- single contact grid area end -->
									</div>
									<div class="col-xxl-3 col-xl-4 col-lg-4 col-md-6 col-sm-12">
										<!-- single contact grid area start -->
										<div class="single-contact-grid-area">
											<div class="top-area">
												<div class="avatar">
													<img src="<?= base_url('assets/img/contact/05.png') ?>" alt="">
												</div>
												<div class="action-area">
													<div class="single">
														<i class="uil uil-heart"></i>
													</div>
													<div class="single geex-content__chat__header__filter__btn">
														<i class="uil uil-ellipsis-v"></i>
													</div>

													<div class="geex-content__chat__header__filter__content">
														<a class="dropdown-item" href="#">view</a>
														<a class="dropdown-item" href="#">Edit</a>
														<a class="dropdown-item" href="#">Details</a>
													</div>
												</div>
											</div>
											<div class="details-area">
												<h4 class="name">Erika Smitham</h4>
												<span class="designation">Central Usability Officer</span>
												<div class="contact-wrapper">
													<a href="#" class="single-contact">
														<i class="uil uil-bag"></i>
														<p>Highspeed Studios</p>
													</a>
													<a href="#" class="single-contact">
														<i class="uil uil-phone"></i>
														<p>+012 345 689</p>
													</a>
													<a href="#" class="single-contact">
														<i class="uil uil-envelope"></i>
														<p>tamara@mail.com</p>
													</a>
												</div>
											</div>
										</div>
										<!-- single contact grid area end -->
									</div>
									<div class="col-xxl-3 col-xl-4 col-lg-4 col-md-6 col-sm-12">
										<!-- single contact grid area start -->
										<div class="single-contact-grid-area">
											<div class="top-area">
												<div class="avatar">
													<img src="<?= base_url('assets/img/contact/06.png') ?>" alt="avatar">
												</div>
												<div class="action-area">
													<div class="single">
														<i class="uil uil-heart"></i>
													</div>
													<div class="single geex-content__chat__header__filter__btn">
														<i class="uil uil-ellipsis-v"></i>
													</div>

													<div class="geex-content__chat__header__filter__content">
														<a class="dropdown-item" href="#">view</a>
														<a class="dropdown-item" href="#">Edit</a>
														<a class="dropdown-item" href="#">Details</a>
													</div>
												</div>
											</div>
											<div class="details-area">
												<h4 class="name">Franklin Stiedemann</h4>
												<span class="designation">Chief Tactics Supervisor</span>
												<div class="contact-wrapper">
													<a href="#" class="single-contact">
														<i class="uil uil-bag"></i>
														<p>Highspeed Studios</p>
													</a>
													<a href="#" class="single-contact">
														<i class="uil uil-phone"></i>
														<p>+012 345 689</p>
													</a>
													<a href="#" class="single-contact">
														<i class="uil uil-envelope"></i>
														<p>tamara@mail.com</p>
													</a>
												</div>
											</div>
										</div>
										<!-- single contact grid area end -->
									</div>
									<div class="col-xxl-3 col-xl-4 col-lg-4 col-md-6 col-sm-12">
										<!-- single contact grid area start -->
										<div class="single-contact-grid-area">
											<div class="top-area">
												<div class="avatar">
													<img src="<?= base_url('assets/img/contact/07.png') ?>" alt="">
												</div>
												<div class="action-area">
													<div class="single">
														<i class="uil uil-heart"></i>
													</div>
													<div class="single geex-content__chat__header__filter__btn">
														<i class="uil uil-ellipsis-v"></i>
													</div>

													<div class="geex-content__chat__header__filter__content">
														<a class="dropdown-item" href="#">view</a>
														<a class="dropdown-item" href="#">Edit</a>
														<a class="dropdown-item" href="#">Details</a>
													</div>
												</div>
											</div>
											<div class="details-area">
												<h4 class="name">Geovanny Bruen</h4>
												<span class="designation">UI Designer</span>
												<div class="contact-wrapper">
													<a href="#" class="single-contact">
														<i class="uil uil-bag"></i>
														<p>Highspeed Studios</p>
													</a>
													<a href="#" class="single-contact">
														<i class="uil uil-phone"></i>
														<p>+012 345 689</p>
													</a>
													<a href="#" class="single-contact">
														<i class="uil uil-envelope"></i>
														<p>tamara@mail.com</p>
													</a>
												</div>
											</div>
										</div>
										<!-- single contact grid area end -->
									</div>
									<div class="col-xxl-3 col-xl-4 col-lg-4 col-md-6 col-sm-12">
										<!-- single contact grid area start -->
										<div class="single-contact-grid-area">
											<div class="top-area">
												<div class="avatar">
													<img src="<?= base_url('assets/img/contact/08.png') ?>" alt="">
												</div>
												<div class="action-area">
													<div class="single">
														<i class="uil uil-heart"></i>
													</div>
													<div class="single geex-content__chat__header__filter__btn">
														<i class="uil uil-ellipsis-v"></i>
													</div>

													<div class="geex-content__chat__header__filter__content">
														<a class="dropdown-item" href="#">view</a>
														<a class="dropdown-item" href="#">Edit</a>
														<a class="dropdown-item" href="#">Details</a>
													</div>
												</div>
											</div>
											<div class="details-area">
												<h4 class="name">John Okuneva</h4>
												<span class="designation">District Mobility Designer</span>
												<div class="contact-wrapper">
													<a href="#" class="single-contact">
														<i class="uil uil-bag"></i>
														<p>Highspeed Studios</p>
													</a>
													<a href="#" class="single-contact">
														<i class="uil uil-phone"></i>
														<p>+012 345 689</p>
													</a>
													<a href="#" class="single-contact">
														<i class="uil uil-envelope"></i>
														<p>tamara@mail.com</p>
													</a>
												</div>
											</div>
										</div>
										<!-- single contact grid area end -->
									</div>


									<div class="col-xxl-3 col-xl-4 col-lg-4 col-md-6 col-sm-12">
										<!-- single contact grid area start -->
										<div class="single-contact-grid-area">
											<div class="top-area">
												<div class="avatar">
													<img src="<?= base_url('assets/img/contact/09.png') ?>" alt="">
												</div>
												<div class="action-area">
													<div class="single">
														<i class="uil uil-heart"></i>
													</div>
													<div class="single geex-content__chat__header__filter__btn">
														<i class="uil uil-ellipsis-v"></i>
													</div>

													<div class="geex-content__chat__header__filter__content">
														<a class="dropdown-item" href="#">view</a>
														<a class="dropdown-item" href="#">Edit</a>
														<a class="dropdown-item" href="#">Details</a>
													</div>
												</div>
											</div>
											<div class="details-area">
												<h4 class="name">Tamara Scevenko</h4>
												<span class="designation">Central Usability Officer</span>
												<div class="contact-wrapper">
													<a href="#" class="single-contact">
														<i class="uil uil-bag"></i>
														<p>Highspeed Studios</p>
													</a>
													<a href="#" class="single-contact">
														<i class="uil uil-phone"></i>
														<p>+012 345 689</p>
													</a>
													<a href="#" class="single-contact">
														<i class="uil uil-envelope"></i>
														<p>tamara@mail.com</p>
													</a>
												</div>
											</div>
										</div>
										<!-- single contact grid area end -->
									</div>
									<div class="col-xxl-3 col-xl-4 col-lg-4 col-md-6 col-sm-12">
										<!-- single contact grid area start -->
										<div class="single-contact-grid-area">
											<div class="top-area">
												<div class="avatar">
													<img src="<?= base_url('assets/img/contact/10.png') ?>" alt="avatar">
												</div>
												<div class="action-area">
													<div class="single">
														<i class="uil uil-heart"></i>
													</div>
													<div class="single geex-content__chat__header__filter__btn">
														<i class="uil uil-ellipsis-v"></i>
													</div>

													<div class="geex-content__chat__header__filter__content">
														<a class="dropdown-item" href="#">view</a>
														<a class="dropdown-item" href="#">Edit</a>
														<a class="dropdown-item" href="#">Details</a>
													</div>
												</div>
											</div>
											<div class="details-area">
												<h4 class="name">Thomas Wunsch</h4>
												<span class="designation">Chief Tactics Supervisor</span>
												<div class="contact-wrapper">
													<a href="#" class="single-contact">
														<i class="uil uil-bag"></i>
														<p>Highspeed Studios</p>
													</a>
													<a href="#" class="single-contact">
														<i class="uil uil-phone"></i>
														<p>+012 345 689</p>
													</a>
													<a href="#" class="single-contact">
														<i class="uil uil-envelope"></i>
														<p>tamara@mail.com</p>
													</a>
												</div>
											</div>
										</div>
										<!-- single contact grid area end -->
									</div>
									<div class="col-xxl-3 col-xl-4 col-lg-4 col-md-6 col-sm-12">
										<!-- single contact grid area start -->
										<div class="single-contact-grid-area">
											<div class="top-area">
												<div class="avatar">
													<img src="<?= base_url('assets/img/contact/11.png') ?>" alt="">
												</div>
												<div class="action-area">
													<div class="single">
														<i class="uil uil-heart"></i>
													</div>
													<div class="single geex-content__chat__header__filter__btn">
														<i class="uil uil-ellipsis-v"></i>
													</div>

													<div class="geex-content__chat__header__filter__content">
														<a class="dropdown-item" href="#">view</a>
														<a class="dropdown-item" href="#">Edit</a>
														<a class="dropdown-item" href="#">Details</a>
													</div>
												</div>
											</div>
											<div class="details-area">
												<h4 class="name">Veronica Hodkiewicz</h4>
												<span class="designation">UI Designer</span>
												<div class="contact-wrapper">
													<a href="#" class="single-contact">
														<i class="uil uil-bag"></i>
														<p>Highspeed Studios</p>
													</a>
													<a href="#" class="single-contact">
														<i class="uil uil-phone"></i>
														<p>+012 345 689</p>
													</a>
													<a href="#" class="single-contact">
														<i class="uil uil-envelope"></i>
														<p>tamara@mail.com</p>
													</a>
												</div>
											</div>
										</div>
										<!-- single contact grid area end -->
									</div>
									<div class="col-xxl-3 col-xl-4 col-lg-4 col-md-6 col-sm-12">
										<!-- single contact grid area start -->
										<div class="single-contact-grid-area">
											<div class="top-area">
												<div class="avatar">
													<img src="<?= base_url('assets/img/contact/12.png') ?>" alt="">
												</div>
												<div class="action-area">
													<div class="single">
														<i class="uil uil-heart"></i>
													</div>
													<div class="single geex-content__chat__header__filter__btn">
														<i class="uil uil-ellipsis-v"></i>
													</div>

													<div class="geex-content__chat__header__filter__content">
														<a class="dropdown-item" href="#">view</a>
														<a class="dropdown-item" href="#">Edit</a>
														<a class="dropdown-item" href="#">Details</a>
													</div>
												</div>
											</div>
											<div class="details-area">
												<h4 class="name">David Koelpin</h4>
												<span class="designation">District Mobility Designer</span>
												<div class="contact-wrapper">
													<a href="#" class="single-contact">
														<i class="uil uil-bag"></i>
														<p>Highspeed Studios</p>
													</a>
													<a href="#" class="single-contact">
														<i class="uil uil-phone"></i>
														<p>+012 345 689</p>
													</a>
													<a href="#" class="single-contact">
														<i class="uil uil-envelope"></i>
														<p>tamara@mail.com</p>
													</a>
												</div>
											</div>
										</div>
										<!-- single contact grid area end -->
									</div>
								</div>
							</div>
						</div>
						<div class="geex-content__todo__footer">
							<div class="geex-content__todo__footer__text">Showing 4 of 256 data</div>
							<div class="geex-content__todo__footer__pagination">
								<ul class="geex-pagination">
									<li class="geex-pagination__item">
										<a href="#" class="geex-pagination__link active">1</a>
									</li>
									<li class="geex-pagination__item">
										<a href="#" class="geex-pagination__link">2</a>
									</li>
									<li class="geex-pagination__item">
										<a href="#" class="geex-pagination__link">3</a>
									</li>
								</ul>
							</div>
						</div>
					</div>
					<div class="tab-pane fade" id="geex-todo-task-content-completed">
						<div class="geex-content__todo__header">
							<div class="geex-content__todo__header__title">
								<i class="uil-info-circle"></i>
								<h4> Completed Task</h4>
							</div>
							<ul class="nav nav-tabs geex-todo-tab geex-content__todo__header__filter" id="geex-todo-tab-completed" role="tablist">
								<li class="geex-content__todo__header__filter__sortby">
									<select>
										<option value="newest">Newest</option>
										<option value="oldest">Oldest</option>
										<option value="name">Name</option>
									</select>
									<i class="uil-angle-down"></i>
								</li>
								<li class="nav-item" role="presentation">
									<a href="#" id="todo_list_tab-completed" class="active" data-bs-toggle="tab" data-bs-target="#todo_list_content-completed" type="button" role="tab" aria-controls="todo_list_content-completed" aria-selected="false">
										<i class="uil-bars"></i>
									</a>
								</li>
								<li class="nav-item" role="presentation">
									<a href="#" id="todo_grid_tab-completed" data-bs-toggle="tab" data-bs-target="#todo_grid_content-completed" type="button" role="tab" aria-controls="todo_grid_contant" aria-selected="false">
										<i class="uil-apps"></i>
									</a>
								</li>
							</ul>
						</div>
						<div class="tab-content geex-transaction-content">
							<div class="tab-pane fade show active" id="todo_list_content-completed" role="tabpanel" aria-labelledby="todo_list_tab-completed">
								<div class="geex-content__todo__list">
									<div class="geex-content__todo__list__single">
										<div class="geex-content__todo__list__single__checkbox">
											<input type="checkbox" name="completed-todo-1" id="completed-todo-1" />
											<label for="completed-todo-1">
												<i class="uil-check"></i>
											</label>
										</div>

										<div class="geex-content__todo__list__single__text">
											<span class="geex-content__todo__list__single__subtitle">January 24th, 2021  04:25 PM</span>
											<h4 class="geex-content__todo__list__single__title">Create custom floating action buttton in Geex Mobile</h4>
										</div>

										<div class="geex-content__todo__list__single__tag">
											<a href="#" class="geex-content__todo__list__single__tag__item primary">
												<i class="uil uil-tag-alt"></i>
												Team
											</a>
											<a href="#" class="geex-content__todo__list__single__tag__item warning">
												<i class="uil uil-tag-alt"></i>
												Important
											</a>
										</div>

										<div class="geex-content__todo__list__single__author">
											<a href="#" class="geex-content__todo__list__single__author__img">
												<img src="<?= base_url('assets/img/avatar/todo/1.svg') ?>" alt="avatar" />
											</a>
											<a href="#" class="geex-content__todo__list__single__author__img">
												<img src="<?= base_url('assets/img/avatar/todo/2.svg') ?>" alt="avatar" />
											</a>
											<a href="#" class="geex-content__todo__list__single__author__img">
												<img src="<?= base_url('assets/img/avatar/todo/3.svg') ?>" alt="avatar" />
											</a>
										</div>
									</div>
									<div class="geex-content__todo__list__single">
										<div class="geex-content__todo__list__single__checkbox">
											<input type="checkbox" name="completed-todo-2" id="completed-todo-2" />
											<label for="completed-todo-2">
												<i class="uil-check"></i>
											</label>
										</div>

										<div class="geex-content__todo__list__single__text">
											<span class="geex-content__todo__list__single__subtitle">January 24th, 2021  04:25 PM</span>
											<h4 class="geex-content__todo__list__single__title">Revision 1 : Remove background in main banner Geex Website</h4>
										</div>

										<div class="geex-content__todo__list__single__tag">
											<a href="#" class="geex-content__todo__list__single__tag__item primary">
												<i class="uil uil-tag-alt"></i>
												Team
											</a>
											<a href="#" class="geex-content__todo__list__single__tag__item danger">
												<i class="uil uil-tag-alt"></i>
												High
											</a>
										</div>

										<div class="geex-content__todo__list__single__author">
											<a href="#" class="geex-content__todo__list__single__author__img">
												<img src="<?= base_url('assets/img/avatar/todo/4.svg') ?>" alt="avatar" />
											</a>
											<a href="#" class="geex-content__todo__list__single__author__img">
												<img src="<?= base_url('assets/img/avatar/todo/5.svg') ?>" alt="avatar" />
											</a>
										</div>
									</div>
								</div>
							</div>
							<div class="tab-pane fade" id="todo_grid_content-completed" role="tabpanel" aria-labelledby="todo_grid_tab-completed">
								<div class="geex-content__todo__list geex-content__todo__list--grid">
									<div class="geex-content__todo__list__single">
										<div class="geex-content__todo__list__single__checkbox">
											<input type="checkbox" name="completed-todo-11" id="completed-todo-11" />
											<label for="completed-todo-11">
												<i class="uil-check"></i>
											</label>
										</div>

										<div class="geex-content__todo__list__single__text">
											<span class="geex-content__todo__list__single__subtitle">January 24th, 2021  04:25 PM</span>
											<h4 class="geex-content__todo__list__single__title">Create custom floating action buttton in Geex Mobile</h4>
										</div>

										<div class="geex-content__todo__list__single__tag">
											<a href="#" class="geex-content__todo__list__single__tag__item primary">
												<i class="uil uil-tag-alt"></i>
												Team
											</a>
											<a href="#" class="geex-content__todo__list__single__tag__item warning">
												<i class="uil uil-tag-alt"></i>
												Important
											</a>
										</div>

										<div class="geex-content__todo__list__single__author">
											<a href="#" class="geex-content__todo__list__single__author__img">
												<img src="<?= base_url('assets/img/avatar/todo/1.svg') ?>" alt="avatar" />
											</a>
											<a href="#" class="geex-content__todo__list__single__author__img">
												<img src="<?= base_url('assets/img/avatar/todo/2.svg') ?>" alt="avatar" />
											</a>
											<a href="#" class="geex-content__todo__list__single__author__img">
												<img src="<?= base_url('assets/img/avatar/todo/3.svg') ?>" alt="avatar" />
											</a>
										</div>
									</div>
									<div class="geex-content__todo__list__single">
										<div class="geex-content__todo__list__single__checkbox">
											<input type="checkbox" name="completed-todo-12" id="completed-todo-12" />
											<label for="completed-todo-12">
												<i class="uil-check"></i>
											</label>
										</div>

										<div class="geex-content__todo__list__single__text">
											<span class="geex-content__todo__list__single__subtitle">January 24th, 2021  04:25 PM</span>
											<h4 class="geex-content__todo__list__single__title">Revision 1 : Remove background in main banner Geex Website</h4>
										</div>

										<div class="geex-content__todo__list__single__tag">
											<a href="#" class="geex-content__todo__list__single__tag__item primary">
												<i class="uil uil-tag-alt"></i>
												Team
											</a>
											<a href="#" class="geex-content__todo__list__single__tag__item danger">
												<i class="uil uil-tag-alt"></i>
												High
											</a>
										</div>

										<div class="geex-content__todo__list__single__author">
											<a href="#" class="geex-content__todo__list__single__author__img">
												<img src="<?= base_url('assets/img/avatar/todo/4.svg') ?>" alt="avatar" />
											</a>
											<a href="#" class="geex-content__todo__list__single__author__img">
												<img src="<?= base_url('assets/img/avatar/todo/5.svg') ?>" alt="avatar" />
											</a>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="tab-pane fade" id="geex-todo-task-content-removed">
						<div class="geex-content__todo__header">
							<div class="geex-content__todo__header__title">
								<i class="uil-info-circle"></i>
								<h4> Removed Task</h4>
							</div>
							<ul class="nav nav-tabs geex-todo-tab geex-content__todo__header__filter" id="geex-todo-removed" role="tablist">
								<li class="geex-content__todo__header__filter__sortby">
									<select>
										<option value="newest">Newest</option>
										<option value="oldest">Oldest</option>
										<option value="name">Name</option>
									</select>
									<i class="uil-angle-down"></i>
								</li>
								<li class="nav-item" role="presentation">
									<a href="#" id="todo_list_tab-removed" class="active" data-bs-toggle="tab" data-bs-target="#todo_list_content-removed" type="button" role="tab" aria-controls="todo_list_content-removed" aria-selected="false">
										<i class="uil-bars"></i>
									</a>
								</li>
								<li class="nav-item" role="presentation">
									<a href="#" id="todo_grid_tab-removed" data-bs-toggle="tab" data-bs-target="#todo_grid_content-removed" type="button" role="tab" aria-controls="todo_grid_contant-removed" aria-selected="false">
										<i class="uil-apps"></i>
									</a>
								</li>
							</ul>
						</div>
						<div class="tab-content geex-transaction-content">
							<div class="tab-pane fade show active" id="todo_list_content-removed" role="tabpanel" aria-labelledby="todo_list_tab-removed">
								<div class="geex-content__todo__list">
									<div class="geex-content__todo__list__single">
										<div class="geex-content__todo__list__single__checkbox">
											<input type="checkbox" name="removed-todo-1" id="removed-todo-1" />
											<label for="removed-todo-1">
												<i class="uil-check"></i>
											</label>
										</div>

										<div class="geex-content__todo__list__single__text">
											<span class="geex-content__todo__list__single__subtitle">January 24th, 2021  04:25 PM</span>
											<h4 class="geex-content__todo__list__single__title">Create custom floating action buttton in Geex Mobile</h4>
										</div>

										<div class="geex-content__todo__list__single__tag">
											<a href="#" class="geex-content__todo__list__single__tag__item primary">
												<i class="uil uil-tag-alt"></i>
												Team
											</a>
											<a href="#" class="geex-content__todo__list__single__tag__item warning">
												<i class="uil uil-tag-alt"></i>
												Important
											</a>
										</div>

										<div class="geex-content__todo__list__single__author">
											<a href="#" class="geex-content__todo__list__single__author__img">
												<img src="<?= base_url('assets/img/avatar/todo/1.svg') ?>" alt="avatar" />
											</a>
											<a href="#" class="geex-content__todo__list__single__author__img">
												<img src="<?= base_url('assets/img/avatar/todo/2.svg') ?>" alt="avatar" />
											</a>
											<a href="#" class="geex-content__todo__list__single__author__img">
												<img src="<?= base_url('assets/img/avatar/todo/3.svg') ?>" alt="avatar" />
											</a>
										</div>
									</div>
									<div class="geex-content__todo__list__single">
										<div class="geex-content__todo__list__single__checkbox">
											<input type="checkbox" name="removed-todo-2" id="removed-todo-2" />
											<label for="removed-todo-2">
												<i class="uil-check"></i>
											</label>
										</div>

										<div class="geex-content__todo__list__single__text">
											<span class="geex-content__todo__list__single__subtitle">January 24th, 2021  04:25 PM</span>
											<h4 class="geex-content__todo__list__single__title">Revision 1 : Remove background in main banner Geex Website</h4>
										</div>

										<div class="geex-content__todo__list__single__tag">
											<a href="#" class="geex-content__todo__list__single__tag__item primary">
												<i class="uil uil-tag-alt"></i>
												Team
											</a>
											<a href="#" class="geex-content__todo__list__single__tag__item danger">
												<i class="uil uil-tag-alt"></i>
												High
											</a>
										</div>

										<div class="geex-content__todo__list__single__author">
											<a href="#" class="geex-content__todo__list__single__author__img">
												<img src="<?= base_url('assets/img/avatar/todo/4.svg') ?>" alt="avatar" />
											</a>
											<a href="#" class="geex-content__todo__list__single__author__img">
												<img src="<?= base_url('assets/img/avatar/todo/5.svg') ?>" alt="avatar" />
											</a>
										</div>
									</div>
								</div>
							</div>
							<div class="tab-pane fade" id="todo_grid_content-removed" role="tabpanel" aria-labelledby="todo_grid_tab-removed">
								<div class="geex-content__todo__list geex-content__todo__list--grid">
									<div class="geex-content__todo__list__single">
										<div class="geex-content__todo__list__single__checkbox">
											<input type="checkbox" name="removed-todo-11" id="removed-todo-11" />
											<label for="removed-todo-11">
												<i class="uil-check"></i>
											</label>
										</div>

										<div class="geex-content__todo__list__single__text">
											<span class="geex-content__todo__list__single__subtitle">January 24th, 2021  04:25 PM</span>
											<h4 class="geex-content__todo__list__single__title">Create custom floating action buttton in Geex Mobile</h4>
										</div>

										<div class="geex-content__todo__list__single__tag">
											<a href="#" class="geex-content__todo__list__single__tag__item primary">
												<i class="uil uil-tag-alt"></i>
												Team
											</a>
											<a href="#" class="geex-content__todo__list__single__tag__item warning">
												<i class="uil uil-tag-alt"></i>
												Important
											</a>
										</div>

										<div class="geex-content__todo__list__single__author">
											<a href="#" class="geex-content__todo__list__single__author__img">
												<img src="<?= base_url('assets/img/avatar/todo/1.svg') ?>" alt="avatar" />
											</a>
											<a href="#" class="geex-content__todo__list__single__author__img">
												<img src="<?= base_url('assets/img/avatar/todo/2.svg') ?>" alt="avatar" />
											</a>
											<a href="#" class="geex-content__todo__list__single__author__img">
												<img src="<?= base_url('assets/img/avatar/todo/3.svg') ?>" alt="avatar" />
											</a>
										</div>
									</div>
									<div class="geex-content__todo__list__single">
										<div class="geex-content__todo__list__single__checkbox">
											<input type="checkbox" name="removed-todo-12" id="removed-todo-12" />
											<label for="removed-todo-12">
												<i class="uil-check"></i>
											</label>
										</div>

										<div class="geex-content__todo__list__single__text">
											<span class="geex-content__todo__list__single__subtitle">January 24th, 2021  04:25 PM</span>
											<h4 class="geex-content__todo__list__single__title">Revision 1 : Remove background in main banner Geex Website</h4>
										</div>

										<div class="geex-content__todo__list__single__tag">
											<a href="#" class="geex-content__todo__list__single__tag__item primary">
												<i class="uil uil-tag-alt"></i>
												Team
											</a>
											<a href="#" class="geex-content__todo__list__single__tag__item danger">
												<i class="uil uil-tag-alt"></i>
												High
											</a>
										</div>

										<div class="geex-content__todo__list__single__author">
											<a href="#" class="geex-content__todo__list__single__author__img">
												<img src="<?= base_url('assets/img/avatar/todo/4.svg') ?>" alt="avatar" />
											</a>
											<a href="#" class="geex-content__todo__list__single__author__img">
												<img src="<?= base_url('assets/img/avatar/todo/5.svg') ?>" alt="avatar" />
											</a>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="tab-pane fade" id="geex-todo-task-content-due">
						<div class="geex-content__todo__header">
							<div class="geex-content__todo__header__title">
								<i class="uil-info-circle"></i>
								<h4> Due Task</h4>
							</div>
							<ul class="nav nav-tabs geex-todo-tab geex-content__todo__header__filter" id="geex-todo-tab-due" role="tablist">
								<li class="geex-content__todo__header__filter__sortby">
									<select>
										<option value="newest">Newest</option>
										<option value="oldest">Oldest</option>
										<option value="name">Name</option>
									</select>
									<i class="uil-angle-down"></i>
								</li>
								<li class="nav-item" role="presentation">
									<a href="#" id="todo_list_tab-due" class="active" data-bs-toggle="tab" data-bs-target="#todo_list_content-due" type="button" role="tab" aria-controls="todo_list_content-due" aria-selected="false">
										<i class="uil-bars"></i>
									</a>
								</li>
								<li class="nav-item" role="presentation">
									<a href="#" id="todo_grid_tab-due" data-bs-toggle="tab" data-bs-target="#todo_grid_content-due" type="button" role="tab" aria-controls="todo_grid_contant-due" aria-selected="false">
										<i class="uil-apps"></i>
									</a>
								</li>
							</ul>
						</div>
						<div class="tab-content geex-transaction-content">
							<div class="tab-pane fade show active" id="todo_list_content-due" role="tabpanel" aria-labelledby="todo_list_tab-due">
								<div class="geex-content__todo__list">
									<div class="geex-content__todo__list__single">
										<div class="geex-content__todo__list__single__checkbox">
											<input type="checkbox" name="due-todo-1" id="due-todo-1" />
											<label for="due-todo-1">
												<i class="uil-check"></i>
											</label>
										</div>

										<div class="geex-content__todo__list__single__text">
											<span class="geex-content__todo__list__single__subtitle">January 24th, 2021  04:25 PM</span>
											<h4 class="geex-content__todo__list__single__title">Create custom floating action buttton in Geex Mobile</h4>
										</div>

										<div class="geex-content__todo__list__single__tag">
											<a href="#" class="geex-content__todo__list__single__tag__item primary">
												<i class="uil uil-tag-alt"></i>
												Team
											</a>
											<a href="#" class="geex-content__todo__list__single__tag__item warning">
												<i class="uil uil-tag-alt"></i>
												Important
											</a>
										</div>

										<div class="geex-content__todo__list__single__author">
											<a href="#" class="geex-content__todo__list__single__author__img">
												<img src="<?= base_url('assets/img/avatar/todo/1.svg') ?>" alt="avatar" />
											</a>
											<a href="#" class="geex-content__todo__list__single__author__img">
												<img src="<?= base_url('assets/img/avatar/todo/2.svg') ?>" alt="avatar" />
											</a>
											<a href="#" class="geex-content__todo__list__single__author__img">
												<img src="<?= base_url('assets/img/avatar/todo/3.svg') ?>" alt="avatar" />
											</a>
										</div>
									</div>
									<div class="geex-content__todo__list__single">
										<div class="geex-content__todo__list__single__checkbox">
											<input type="checkbox" name="due-todo-2" id="due-todo-2" />
											<label for="due-todo-2">
												<i class="uil-check"></i>
											</label>
										</div>

										<div class="geex-content__todo__list__single__text">
											<span class="geex-content__todo__list__single__subtitle">January 24th, 2021  04:25 PM</span>
											<h4 class="geex-content__todo__list__single__title">Revision 1 : Remove background in main banner Geex Website</h4>
										</div>

										<div class="geex-content__todo__list__single__tag">
											<a href="#" class="geex-content__todo__list__single__tag__item primary">
												<i class="uil uil-tag-alt"></i>
												Team
											</a>
											<a href="#" class="geex-content__todo__list__single__tag__item danger">
												<i class="uil uil-tag-alt"></i>
												High
											</a>
										</div>

										<div class="geex-content__todo__list__single__author">
											<a href="#" class="geex-content__todo__list__single__author__img">
												<img src="<?= base_url('assets/img/avatar/todo/4.svg') ?>" alt="avatar" />
											</a>
											<a href="#" class="geex-content__todo__list__single__author__img">
												<img src="<?= base_url('assets/img/avatar/todo/5.svg') ?>" alt="avatar" />
											</a>
										</div>
									</div>
								</div>
							</div>
							<div class="tab-pane fade" id="todo_grid_content-due" role="tabpanel" aria-labelledby="todo_grid_tab-due">
								<div class="geex-content__todo__list geex-content__todo__list--grid">
									<div class="geex-content__todo__list__single">
										<div class="geex-content__todo__list__single__checkbox">
											<input type="checkbox" name="due-todo-11" id="due-todo-11" />
											<label for="due-todo-11">
												<i class="uil-check"></i>
											</label>
										</div>

										<div class="geex-content__todo__list__single__text">
											<span class="geex-content__todo__list__single__subtitle">January 24th, 2021  04:25 PM</span>
											<h4 class="geex-content__todo__list__single__title">Create custom floating action buttton in Geex Mobile</h4>
										</div>

										<div class="geex-content__todo__list__single__tag">
											<a href="#" class="geex-content__todo__list__single__tag__item primary">
												<i class="uil uil-tag-alt"></i>
												Team
											</a>
											<a href="#" class="geex-content__todo__list__single__tag__item warning">
												<i class="uil uil-tag-alt"></i>
												Important
											</a>
										</div>

										<div class="geex-content__todo__list__single__author">
											<a href="#" class="geex-content__todo__list__single__author__img">
												<img src="<?= base_url('assets/img/avatar/todo/1.svg') ?>" alt="avatar" />
											</a>
											<a href="#" class="geex-content__todo__list__single__author__img">
												<img src="<?= base_url('assets/img/avatar/todo/2.svg') ?>" alt="avatar" />
											</a>
											<a href="#" class="geex-content__todo__list__single__author__img">
												<img src="<?= base_url('assets/img/avatar/todo/3.svg') ?>" alt="avatar" />
											</a>
										</div>
									</div>
									<div class="geex-content__todo__list__single">
										<div class="geex-content__todo__list__single__checkbox">
											<input type="checkbox" name="due-todo-12" id="due-todo-12" />
											<label for="due-todo-12">
												<i class="uil-check"></i>
											</label>
										</div>

										<div class="geex-content__todo__list__single__text">
											<span class="geex-content__todo__list__single__subtitle">January 24th, 2021  04:25 PM</span>
											<h4 class="geex-content__todo__list__single__title">Revision 1 : Remove background in main banner Geex Website</h4>
										</div>

										<div class="geex-content__todo__list__single__tag">
											<a href="#" class="geex-content__todo__list__single__tag__item primary">
												<i class="uil uil-tag-alt"></i>
												Team
											</a>
											<a href="#" class="geex-content__todo__list__single__tag__item danger">
												<i class="uil uil-tag-alt"></i>
												High
											</a>
										</div>

										<div class="geex-content__todo__list__single__author">
											<a href="#" class="geex-content__todo__list__single__author__img">
												<img src="<?= base_url('assets/img/avatar/todo/4.svg') ?>" alt="avatar" />
											</a>
											<a href="#" class="geex-content__todo__list__single__author__img">
												<img src="<?= base_url('assets/img/avatar/todo/5.svg') ?>" alt="avatar" />
											</a>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="geex-content__modal__form">
				<div class="geex-content__modal__form__header">
					<h3 class="geex-content__modal__form__title">Add New Contact</h3>
					<button class="geex-content__modal__form__close">
						<i class="uil-times"></i>
					</button>
				</div>
				<form class="geex-content__modal__form__wrapper">
					<div class="geex-content__modal__form__item">
						<input type="text" name="geex-content__modal__form__name" class="geex-content__modal__form__input" placeholder="Name" />
					</div>
					<div class="geex-content__modal__form__item">
						<input type="text" name="geex-content__modal__form__name" class="geex-content__modal__form__input" placeholder="Designation" />
					</div>
					<div class="geex-content__modal__form__item">
						<input type="text" name="geex-content__modal__form__name" class="geex-content__modal__form__input" placeholder="Studio Name" />
					</div>
					<div class="geex-content__modal__form__item">
						<input type="text" name="geex-content__modal__form__name" class="geex-content__modal__form__input" placeholder="Phone Number" />
					</div>
					<div class="geex-content__modal__form__item">
						<input type="text" name="geex-content__modal__form__name" class="geex-content__modal__form__input" placeholder="Email Address" />
					</div>
					<div class="geex-content__modal__form__item">
						<button type="submit" class="geex-content__modal__form__submit">Submit</button>
					</div>
				</form>
			</div>
		</div>
	</div>	

<?= $this->endSection(); ?>