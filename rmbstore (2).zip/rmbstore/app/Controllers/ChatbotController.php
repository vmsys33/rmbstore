<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use CodeIgniter\HTTP\CLIRequest;
use CodeIgniter\HTTP\IncomingRequest;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use Psr\Log\LoggerInterface;

class ChatbotController extends Controller
{
    protected $request;
    protected $helpers = ['form', 'url'];
    protected $db;

    public function initController(RequestInterface $request, ResponseInterface $response, LoggerInterface $logger)
    {
        parent::initController($request, $response, $logger);
        $this->db = \Config\Database::connect();
    }

    /**
     * Get products for chatbot search
     */
    public function getProducts()
    {
        try {
            $query = $this->db->table('chatbot_products')
                ->where('status', 'active')
                ->orderBy('name', 'ASC')
                ->get();

            $products = $query->getResultArray();

            return $this->response->setJSON([
                'status' => 'success',
                'data' => $products,
                'count' => count($products)
            ]);
        } catch (\Exception $e) {
            return $this->response->setJSON([
                'status' => 'error',
                'message' => 'Failed to fetch products: ' . $e->getMessage()
            ])->setStatusCode(500);
        }
    }

    /**
     * Search products by query
     */
    public function searchProducts()
    {
        try {
            $query = $this->request->getGet('q');
            
            if (empty($query)) {
                return $this->response->setJSON([
                    'status' => 'error',
                    'message' => 'Search query is required'
                ])->setStatusCode(400);
            }

            $builder = $this->db->table('chatbot_products');
            $builder->where('status', 'active');
            $builder->groupStart()
                ->like('name', $query)
                ->orLike('description', $query)
                ->orLike('category', $query)
                ->orLike('keywords', $query)
            ->groupEnd();
            
            $results = $builder->get()->getResultArray();

            return $this->response->setJSON([
                'status' => 'success',
                'data' => $results,
                'count' => count($results),
                'query' => $query
            ]);
        } catch (\Exception $e) {
            return $this->response->setJSON([
                'status' => 'error',
                'message' => 'Search failed: ' . $e->getMessage()
            ])->setStatusCode(500);
        }
    }

    /**
     * Get Q&A responses
     */
    public function getQA()
    {
        try {
            $query = $this->db->table('chatbot_qa')
                ->where('status', 'active')
                ->orderBy('priority', 'ASC')
                ->orderBy('category', 'ASC')
                ->get();

            $qa = $query->getResultArray();

            return $this->response->setJSON([
                'status' => 'success',
                'data' => $qa,
                'count' => count($qa)
            ]);
        } catch (\Exception $e) {
            return $this->response->setJSON([
                'status' => 'error',
                'message' => 'Failed to fetch Q&A: ' . $e->getMessage()
            ])->setStatusCode(500);
        }
    }

    /**
     * Search Q&A by question or keywords
     */
    public function searchQA()
    {
        try {
            $query = $this->request->getGet('q');
            
            if (empty($query)) {
                return $this->response->setJSON([
                    'status' => 'error',
                    'message' => 'Search query is required'
                ])->setStatusCode(400);
            }

            $builder = $this->db->table('chatbot_qa');
            $builder->where('status', 'active');
            $builder->groupStart()
                ->like('question', $query)
                ->orLike('answer', $query)
                ->orLike('keywords', $query)
                ->orLike('category', $query)
            ->groupEnd();
            
            $results = $builder->get()->getResultArray();

            return $this->response->setJSON([
                'status' => 'success',
                'data' => $results,
                'count' => count($results),
                'query' => $query
            ]);
        } catch (\Exception $e) {
            return $this->response->setJSON([
                'status' => 'error',
                'message' => 'Q&A search failed: ' . $e->getMessage()
            ])->setStatusCode(500);
        }
    }

    /**
     * Get AI response using free AI service
     */
    public function getAIResponse()
    {
        try {
            $message = $this->request->getPost('message');
            
            if (empty($message)) {
                return $this->response->setJSON([
                    'status' => 'error',
                    'message' => 'Message is required'
                ])->setStatusCode(400);
            }

            // Try multiple free AI services
            $aiResponse = $this->getFreeAIResponse($message);

            if ($aiResponse) {
                return $this->response->setJSON([
                    'status' => 'success',
                    'data' => [
                        'response' => $aiResponse,
                        'source' => 'ai_service'
                    ]
                ]);
            } else {
                return $this->response->setJSON([
                    'status' => 'error',
                    'message' => 'AI service temporarily unavailable'
                ])->setStatusCode(503);
            }
        } catch (\Exception $e) {
            return $this->response->setJSON([
                'status' => 'error',
                'message' => 'AI response failed: ' . $e->getMessage()
            ])->setStatusCode(500);
        }
    }

    /**
     * Get response from free AI services
     */
    private function getFreeAIResponse($message)
    {
        // Try Hugging Face Inference API (free tier)
        $response = $this->tryHuggingFace($message);
        if ($response) return $response;

        // Try alternative free service
        $response = $this->tryAlternativeAI($message);
        if ($response) return $response;

        return null;
    }

    /**
     * Try Hugging Face Inference API
     */
    private function tryHuggingFace($message)
    {
        try {
            $url = 'https://api-inference.huggingface.co/models/facebook/blenderbot-400M-distill';
            $data = ['inputs' => $message];
            
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'Content-Type: application/json',
                'User-Agent: RMBStore-Chatbot/1.0'
            ]);
            curl_setopt($ch, CURLOPT_TIMEOUT, 10);
            
            $result = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            
            if ($httpCode === 200 && $result) {
                $response = json_decode($result, true);
                if (isset($response[0]['generated_text'])) {
                    return $response[0]['generated_text'];
                }
            }
        } catch (\Exception $e) {
            log_message('error', 'Hugging Face API error: ' . $e->getMessage());
        }
        
        return null;
    }

    /**
     * Try alternative free AI service
     */
    private function tryAlternativeAI($message)
    {
        try {
            // Simple rule-based responses as fallback
            $fallbackResponses = [
                'hello' => 'Hello! How can I help you today?',
                'help' => 'I\'m here to help! What do you need assistance with?',
                'thanks' => 'You\'re welcome! Is there anything else I can help you with?',
                'bye' => 'Goodbye! Feel free to come back if you need help.',
                'how are you' => 'I\'m doing well, thank you for asking! How can I assist you?'
            ];
            
            $messageLower = strtolower(trim($message));
            foreach ($fallbackResponses as $key => $response) {
                if (strpos($messageLower, $key) !== false) {
                    return $response;
                }
            }
            
            // Generic helpful response
            return "I understand you're asking about: \"$message\". Let me help you find the information you need. You can ask me about our products, services, or policies.";
            
        } catch (\Exception $e) {
            log_message('error', 'Alternative AI error: ' . $e->getMessage());
        }
        
        return null;
    }

    /**
     * Save chat session
     */
    public function saveSession()
    {
        try {
            $sessionId = $this->request->getPost('sessionId');
            $userFingerprint = $this->request->getPost('userFingerprint');
            $userIp = $this->request->getIPAddress();
            $userAgent = $this->request->getPost('userAgent');
            
            // Check if session already exists
            $existingSession = $this->db->table('chatbot_sessions')
                ->where('session_id', $sessionId)
                ->get()
                ->getRow();
            
            if (!$existingSession) {
                // Create new session
                $data = [
                    'session_id' => $sessionId,
                    'user_fingerprint' => $userFingerprint,
                    'user_ip' => $userIp,
                    'user_agent' => $userAgent,
                    'started_at' => date('Y-m-d H:i:s'),
                    'last_activity' => date('Y-m-d H:i:s'),
                    'message_count' => 0
                ];
                
                $this->db->table('chatbot_sessions')->insert($data);
                log_message('info', "New chatbot session created: {$sessionId} for fingerprint: {$userFingerprint}");
            } else {
                // Update existing session
                $this->db->table('chatbot_sessions')
                    ->where('session_id', $sessionId)
                    ->update([
                        'last_activity' => date('Y-m-d H:i:s'),
                        'user_fingerprint' => $userFingerprint
                    ]);
            }
            
            return $this->response->setJSON([
                'success' => true,
                'message' => 'Session saved successfully',
                'sessionId' => $sessionId
            ]);
            
        } catch (Exception $e) {
            log_message('error', 'Error saving chatbot session: ' . $e->getMessage());
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Failed to save session'
            ])->setStatusCode(500);
        }
    }
    
    public function saveMessage()
    {
        try {
            $sessionId = $this->request->getPost('sessionId');
            $userFingerprint = $this->request->getPost('userFingerprint');
            $sender = $this->request->getPost('sender');
            $message = $this->request->getPost('message');
            $messageType = $this->request->getPost('messageType') ?? 'text';
            $metadata = $this->request->getPost('metadata');
            
            // Validate inputs
            if (empty($sessionId) || empty($sender) || empty($message)) {
                return $this->response->setJSON([
                    'success' => false,
                    'message' => 'Missing required fields'
                ])->setStatusCode(400);
            }
            
            // Save message
            $data = [
                'session_id' => $sessionId,
                'user_fingerprint' => $userFingerprint,
                'sender' => $sender,
                'message' => $message,
                'message_type' => $messageType,
                'metadata' => $metadata ? json_encode($metadata) : null,
                'created_at' => date('Y-m-d H:i:s')
            ];
            
            $this->db->table('chatbot_messages')->insert($data);
            
            // Update session message count
            $this->db->table('chatbot_sessions')
                ->where('session_id', $sessionId)
                ->set('message_count', 'message_count + 1', false)
                ->set('last_activity', date('Y-m-d H:i:s'))
                ->update();
            
            log_message('info', "Chatbot message saved: {$sender} - {$message} for session: {$sessionId}");
            
            return $this->response->setJSON([
                'success' => true,
                'message' => 'Message saved successfully'
            ]);
            
        } catch (Exception $e) {
            log_message('error', 'Error saving chatbot message: ' . $e->getMessage());
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Failed to save message'
            ])->setStatusCode(500);
        }
    }
    
    public function getChatHistory()
    {
        try {
            $sessionId = $this->request->getPost('sessionId');
            $userFingerprint = $this->request->getPost('userFingerprint');
            
            // First try to find by session ID
            $messages = $this->db->table('chatbot_messages')
                ->where('session_id', $sessionId)
                ->orderBy('created_at', 'ASC')
                ->get()
                ->getResultArray();
            
            // If no messages found by session ID, try to find by user fingerprint
            if (empty($messages) && !empty($userFingerprint)) {
                $messages = $this->db->table('chatbot_messages')
                    ->where('user_fingerprint', $userFingerprint)
                    ->orderBy('created_at', 'DESC')
                    ->limit(20) // Get last 20 messages
                    ->get()
                    ->getResultArray();
                
                // Reverse to get chronological order
                $messages = array_reverse($messages);
            }
            
            return $this->response->setJSON([
                'success' => true,
                'messages' => $messages,
                'count' => count($messages)
            ]);
            
        } catch (Exception $e) {
            log_message('error', 'Error getting chatbot history: ' . $e->getMessage());
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Failed to get chat history'
            ])->setStatusCode(500);
        }
    }
}
