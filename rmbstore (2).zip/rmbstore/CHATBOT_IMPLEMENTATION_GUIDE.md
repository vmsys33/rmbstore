# 🤖 Multi-User Chatbot System - Implementation Guide
## RMB Store Chatbot Documentation

---

## 📋 Table of Contents
1. [System Overview](#system-overview)
2. [Architecture](#architecture)
3. [Database Schema](#database-schema)
4. [Frontend Implementation](#frontend-implementation)
5. [Backend Implementation](#backend-implementation)
6. [API Endpoints](#api-endpoints)
7. [User Session Management](#user-session-management)
8. [Features & Functionality](#features--functionality)
9. [Installation & Setup](#installation--setup)
10. [Testing Guide](#testing-guide)
11. [Troubleshooting](#troubleshooting)
12. [Maintenance & Updates](#maintenance--updates)

---

## 🎯 System Overview

### What is the Multi-User Chatbot System?
A sophisticated chatbot system that provides:
- **Individual user sessions** - Each user gets their own conversation
- **Persistent chat history** - Messages are saved and retrieved
- **Product search functionality** - Users can search for products
- **Q&A system** - Predefined questions and answers
- **AI integration** - Fallback to AI service for complex queries
- **Professional UI** - Clean, responsive design

### Key Features
- ✅ **Multi-user support** - Unlimited concurrent users
- ✅ **Session persistence** - Chat history across visits
- ✅ **Product search** - Database-driven product lookup
- ✅ **Q&A system** - Knowledge base integration
- ✅ **AI fallback** - Hugging Face API integration
- ✅ **Responsive design** - Mobile-friendly interface
- ✅ **Real-time chat** - Instant message handling
- ✅ **User fingerprinting** - Device-based identification

---

## 🏗️ Architecture

### System Components
```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Frontend      │    │   Backend       │    │   Database      │
│   (JavaScript)  │◄──►│   (PHP/CI4)     │◄──►│   (MySQL)       │
└─────────────────┘    └─────────────────┘    └─────────────────┘
         │                       │                       │
         │                       │                       │
    ┌─────────┐            ┌─────────┐            ┌─────────┐
    │Chatbot  │            │API      │            │Sessions │
    │Widget   │            │Endpoints│            │Messages │
    └─────────┘            └─────────┘            └─────────┘
```

### Technology Stack
- **Frontend**: JavaScript (ES6+), HTML5, CSS3
- **Backend**: PHP 8.0+, CodeIgniter 4
- **Database**: MySQL 8.0+
- **AI Service**: Hugging Face Inference API
- **Server**: Apache/Nginx with XAMPP

---

## 🗄️ Database Schema

### Tables Overview

#### 1. `chatbot_sessions`
Stores user session information for multi-user support.

```sql
CREATE TABLE `chatbot_sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `session_id` varchar(255) NOT NULL,        -- Unique session identifier
  `user_fingerprint` varchar(255) DEFAULT NULL, -- Device fingerprint
  `user_ip` varchar(45),                     -- User's IP address
  `user_agent` text,                         -- Browser information
  `started_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `last_activity` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `message_count` int(11) DEFAULT 0,         -- Total messages in session
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_session_id` (`session_id`),
  KEY `idx_user_fingerprint` (`user_fingerprint`),
  KEY `idx_started_at` (`started_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
```

#### 2. `chatbot_messages`
Stores all chat messages with session linking.

```sql
CREATE TABLE `chatbot_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `session_id` varchar(255) NOT NULL,        -- Links to session
  `user_fingerprint` varchar(255) DEFAULT NULL, -- Device fingerprint
  `sender` enum('user','bot','system') NOT NULL,
  `message` text NOT NULL,                   -- Message content
  `message_type` enum('text','product_search','qa_response','ai_response') DEFAULT 'text',
  `metadata` json,                           -- Additional data (product info, etc.)
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_session_id` (`session_id`),
  KEY `idx_user_fingerprint` (`user_fingerprint`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_sender` (`sender`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
```

#### 3. `chatbot_products`
Stores product information for search functionality.

```sql
CREATE TABLE `chatbot_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,              -- Product name
  `description` text,                        -- Product description
  `category` varchar(100) NOT NULL,          -- Product category
  `price` decimal(10,2) NOT NULL,            -- Product price
  `stock` int(11) DEFAULT 0,                 -- Stock quantity
  `image` varchar(255),                      -- Product image URL
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_category` (`category`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
```

#### 4. `chatbot_qa`
Stores Q&A pairs for knowledge base responses.

```sql
CREATE TABLE `chatbot_qa` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question` text NOT NULL,                  -- Question text
  `answer` text NOT NULL,                    -- Answer text
  `category` varchar(100) DEFAULT 'general', -- Q&A category
  `keywords` text,                           -- Search keywords
  `priority` int(11) DEFAULT 1,              -- Response priority
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_category` (`category`),
  KEY `idx_status` (`status`),
  KEY `idx_priority` (`priority`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
```

---

## 🎨 Frontend Implementation

### File Structure
```
public/assets/frontend/
├── js/
│   └── chatbot.js          # Main chatbot JavaScript
├── css/
│   └── chatbot.css         # Chatbot styling
└── images/
    └── chatbot/            # Chatbot images
```

### Core JavaScript Class: `ChatbotWidget`

#### Constructor
```javascript
class ChatbotWidget {
    constructor() {
        // Session Management
        this.sessionId = this.generateSessionId();
        this.userFingerprint = this.generateUserFingerprint();
        
        // Data Storage
        this.products = [];
        this.qa = [];
        this.messageCount = 0;
        this.messageHistory = [];
        
        // API Configuration
        this.apiBase = '/chatbot';
        
        // Initialize
        this.init();
        this.loadProducts();
        this.loadQA();
        this.saveSession();
        this.loadUserHistory();
    }
}
```

#### Key Methods

##### Session Management
```javascript
generateSessionId() {
    const timestamp = Date.now();
    const random = Math.random().toString(36).substring(2, 15);
    return `session_${timestamp}_${random}`;
}

generateUserFingerprint() {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    ctx.textBaseline = 'top';
    ctx.font = '14px Arial';
    ctx.fillText('User fingerprint', 2, 2);
    
    const fingerprint = canvas.toDataURL();
    const userAgent = navigator.userAgent;
    const screenRes = `${screen.width}x${screen.height}`;
    const timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
    
    const userData = `${fingerprint}_${userAgent}_${screenRes}_${timezone}`;
    return btoa(userData).substring(0, 32);
}
```

##### Message Handling
```javascript
async sendMessage(message) {
    // Add user message to chat
    this.addMessage(message, 'user');
    
    // Generate bot response
    const response = await this.generateResponse(message);
    
    // Add bot response to chat
    this.addMessage(response, 'bot');
}

addMessage(text, sender, saveToDatabase = true) {
    // Create message element
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${sender}-message`;
    
    // Handle HTML content for bot messages
    if (sender === 'bot') {
        messageText.innerHTML = text; // Allow HTML
    } else {
        messageText.textContent = text; // Escape HTML
    }
    
    // Save to database if requested
    if (saveToDatabase) {
        this.saveMessage(sender, text);
    }
}
```

##### Response Generation
```javascript
async generateResponse(userMessage) {
    try {
        // 1. Check Q&A database
        const qaResponse = this.searchQA(userMessage);
        if (qaResponse) return qaResponse;
        
        // 2. Search products
        const productResponse = this.searchProducts(userMessage);
        if (productResponse) return productResponse;
        
        // 3. Use AI service
        const aiResponse = await this.getAIResponse(userMessage);
        if (aiResponse) return aiResponse;
        
        // 4. Default response
        return this.getDefaultResponse();
    } catch (error) {
        console.error('Error generating response:', error);
        return "I'm sorry, I'm having trouble processing your request right now.";
    }
}
```

### CSS Styling

#### Key CSS Classes
```css
/* Chat container */
.chatbot-container {
    position: fixed;
    bottom: 20px;
    right: 20px;
    z-index: 1000;
}

/* Message styling */
.message {
    margin: 10px 0;
    padding: 10px 15px;
    border-radius: 15px;
    max-width: 80%;
}

.user-message {
    background: #007bff;
    color: white;
    margin-left: auto;
}

.bot-message {
    background: #f8f9fa;
    color: #333;
    margin-right: auto;
}

/* Product cards */
.product-card-clean {
    border: 1px solid #e0e0e0;
    border-radius: 8px;
    padding: 10px;
    margin: 5px;
    transition: transform 0.2s;
}

.product-card-clean:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
}
```

---

## 🔧 Backend Implementation

### File Structure
```
app/
├── Controllers/
│   └── ChatbotController.php    # Main chatbot controller
├── Config/
│   └── Routes.php              # API routes
└── Views/
    └── admin/
        └── chatbot_qa.php      # Admin interface
```

### ChatbotController

#### Class Structure
```php
<?php
namespace App\Controllers;

use CodeIgniter\Controller;
use CodeIgniter\HTTP\ResponseInterface;

class ChatbotController extends Controller
{
    protected $db;
    
    public function initController($request, $response, $logger)
    {
        parent::initController($request, $response, $logger);
        $this->db = \Config\Database::connect();
    }
}
```

#### Key Methods

##### Session Management
```php
public function saveSession()
{
    try {
        $sessionId = $this->request->getPost('sessionId');
        $userFingerprint = $this->request->getPost('userFingerprint');
        $userIp = $this->request->getIPAddress();
        $userAgent = $this->request->getPost('userAgent');
        
        // Check if session exists
        $existingSession = $this->db->table('chatbot_sessions')
            ->where('session_id', $sessionId)
            ->get()
            ->getRow();
        
        if (!$existingSession) {
            // Create new session
            $data = [
                'session_id' => $sessionId,
                'user_fingerprint' => $userFingerprint,
                'user_ip' => $userIp,
                'user_agent' => $userAgent,
                'started_at' => date('Y-m-d H:i:s'),
                'last_activity' => date('Y-m-d H:i:s'),
                'message_count' => 0
            ];
            
            $this->db->table('chatbot_sessions')->insert($data);
        } else {
            // Update existing session
            $this->db->table('chatbot_sessions')
                ->where('session_id', $sessionId)
                ->update(['last_activity' => date('Y-m-d H:i:s')]);
        }
        
        return $this->response->setJSON([
            'success' => true,
            'message' => 'Session saved successfully'
        ]);
    } catch (Exception $e) {
        return $this->response->setJSON([
            'success' => false,
            'message' => 'Failed to save session'
        ])->setStatusCode(500);
    }
}
```

##### Message Handling
```php
public function saveMessage()
{
    try {
        $sessionId = $this->request->getPost('sessionId');
        $userFingerprint = $this->request->getPost('userFingerprint');
        $sender = $this->request->getPost('sender');
        $message = $this->request->getPost('message');
        $messageType = $this->request->getPost('messageType') ?? 'text';
        $metadata = $this->request->getPost('metadata');
        
        // Save message
        $data = [
            'session_id' => $sessionId,
            'user_fingerprint' => $userFingerprint,
            'sender' => $sender,
            'message' => $message,
            'message_type' => $messageType,
            'metadata' => $metadata ? json_encode($metadata) : null,
            'created_at' => date('Y-m-d H:i:s')
        ];
        
        $this->db->table('chatbot_messages')->insert($data);
        
        // Update session message count
        $this->db->table('chatbot_sessions')
            ->where('session_id', $sessionId)
            ->set('message_count', 'message_count + 1', false)
            ->set('last_activity', date('Y-m-d H:i:s'))
            ->update();
        
        return $this->response->setJSON([
            'success' => true,
            'message' => 'Message saved successfully'
        ]);
    } catch (Exception $e) {
        return $this->response->setJSON([
            'success' => false,
            'message' => 'Failed to save message'
        ])->setStatusCode(500);
    }
}
```

##### Data Retrieval
```php
public function getProducts()
{
    try {
        $products = $this->db->table('chatbot_products')
            ->where('status', 'active')
            ->get()
            ->getResultArray();
        
        return $this->response->setJSON([
            'success' => true,
            'products' => $products
        ]);
    } catch (Exception $e) {
        return $this->response->setJSON([
            'success' => false,
            'message' => 'Failed to fetch products'
        ])->setStatusCode(500);
    }
}

public function getQA()
{
    try {
        $qa = $this->db->table('chatbot_qa')
            ->where('status', 'active')
            ->orderBy('priority', 'ASC')
            ->get()
            ->getResultArray();
        
        return $this->response->setJSON([
            'success' => true,
            'qa' => $qa
        ]);
    } catch (Exception $e) {
        return $this->response->setJSON([
            'success' => false,
            'message' => 'Failed to fetch Q&A'
        ])->setStatusCode(500);
    }
}
```

---

## 🌐 API Endpoints

### Route Configuration
```php
// app/Config/Routes.php
$routes->group('chatbot', function($routes) {
    $routes->post('saveSession', 'ChatbotController::saveSession');
    $routes->post('saveMessage', 'ChatbotController::saveMessage');
    $routes->post('getChatHistory', 'ChatbotController::getChatHistory');
    $routes->get('getProducts', 'ChatbotController::getProducts');
    $routes->get('getQA', 'ChatbotController::getQA');
    $routes->post('getAIResponse', 'ChatbotController::getAIResponse');
});
```

### Endpoint Details

| Endpoint | Method | Purpose | Parameters |
|----------|--------|---------|------------|
| `/chatbot/saveSession` | POST | Create/update user session | `sessionId`, `userFingerprint`, `userAgent` |
| `/chatbot/saveMessage` | POST | Save chat message | `sessionId`, `userFingerprint`, `sender`, `message` |
| `/chatbot/getChatHistory` | POST | Retrieve chat history | `sessionId`, `userFingerprint` |
| `/chatbot/getProducts` | GET | Get all products | None |
| `/chatbot/getQA` | GET | Get Q&A data | None |
| `/chatbot/getAIResponse` | POST | Get AI response | `message` |

### Response Format
```json
{
    "success": true,
    "message": "Operation completed successfully",
    "data": {
        // Response data
    }
}
```

---

## 👤 User Session Management

### How Sessions Work

#### 1. Session Creation
```javascript
// When user visits website
this.sessionId = this.generateSessionId();        // session_1734876543210_abc123
this.userFingerprint = this.generateUserFingerprint(); // Device fingerprint
```

#### 2. Session Storage
```javascript
// Save session to database
await fetch('/chatbot/saveSession', {
    method: 'POST',
    body: JSON.stringify({
        sessionId: this.sessionId,
        userFingerprint: this.userFingerprint,
        userAgent: navigator.userAgent
    })
});
```

#### 3. Message Association
```javascript
// Every message is linked to session
await fetch('/chatbot/saveMessage', {
    method: 'POST',
    body: JSON.stringify({
        sessionId: this.sessionId,
        userFingerprint: this.userFingerprint,
        sender: 'user',
        message: 'Hello'
    })
});
```

#### 4. History Retrieval
```javascript
// Load user's chat history
const response = await fetch('/chatbot/getChatHistory', {
    method: 'POST',
    body: JSON.stringify({
        sessionId: this.sessionId,
        userFingerprint: this.userFingerprint
    })
});
```

### Multi-User Scenarios

#### Scenario 1: New User
1. User visits website
2. New session created with unique ID
3. Chat history starts fresh
4. Messages saved to new session

#### Scenario 2: Returning User (Same Device)
1. User returns to website
2. Same fingerprint detected
3. Previous chat history loaded
4. "Welcome back!" message shown
5. New messages added to existing session

#### Scenario 3: Multiple Users
1. User A on Chrome → Session A
2. User B on Firefox → Session B
3. User C on mobile → Session C
4. Each has separate conversations

#### Scenario 4: Same User, Different Devices
1. User A on laptop → Session A
2. User A on phone → Session B (different fingerprint)
3. Separate conversations (no history sharing)

---

## ⚡ Features & Functionality

### 1. Product Search
```javascript
searchProducts(query) {
    const searchTerm = query.toLowerCase();
    const foundProducts = this.products.filter(product => {
        return product.name.toLowerCase().includes(searchTerm) ||
               product.category.toLowerCase().includes(searchTerm) ||
               product.name.toLowerCase().split(' ').some(word => searchTerm.includes(word));
    });
    
    if (foundProducts.length > 0) {
        return this.formatProductDisplay(foundProducts);
    }
    return null;
}
```

### 2. Q&A System
```javascript
searchQA(query) {
    const searchTerm = query.toLowerCase();
    const foundQA = this.qa.filter(qa => {
        return qa.question.toLowerCase().includes(searchTerm) ||
               qa.keywords.toLowerCase().includes(searchTerm);
    });
    
    if (foundQA.length > 0) {
        return foundQA[0].answer; // Return first match
    }
    return null;
}
```

### 3. AI Integration
```javascript
async getAIResponse(message) {
    try {
        const response = await fetch(`${this.apiBase}/getAIResponse`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ message: message })
        });
        
        if (response.ok) {
            const data = await response.json();
            return data.response;
        }
    } catch (error) {
        console.error('AI response error:', error);
    }
    return null;
}
```

### 4. Time Format
```javascript
getCurrentTime() {
    const now = new Date();
    let hours = now.getHours();
    const minutes = now.getMinutes().toString().padStart(2, '0');
    const ampm = hours >= 12 ? 'PM' : 'AM';
    
    // Convert to 12-hour format
    hours = hours % 12;
    hours = hours ? hours : 12; // Convert 0 to 12
    
    return `${hours}:${minutes} ${ampm}`;
}
```

---

## 🚀 Installation & Setup

### Prerequisites
- PHP 8.0 or higher
- MySQL 8.0 or higher
- CodeIgniter 4
- XAMPP/WAMP/LAMP stack
- Modern web browser

### Step 1: Database Setup
```bash
# 1. Create database
mysql -u root -p
CREATE DATABASE rmbstore;
USE rmbstore;

# 2. Run setup script
mysql -u root -p rmbstore < database_chatbot_setup.sql
```

### Step 2: File Installation
```bash
# 1. Copy files to project
cp chatbot.js public/assets/frontend/js/
cp chatbot.css public/assets/frontend/css/
cp ChatbotController.php app/Controllers/

# 2. Update routes
# Add chatbot routes to app/Config/Routes.php

# 3. Include in frontend
# Add chatbot HTML and JavaScript to your main page
```

### Step 3: Configuration
```php
// app/Config/Database.php
public $default = [
    'hostname' => 'localhost',
    'username' => 'root',
    'password' => '',
    'database' => 'rmbstore',
    'DBDriver' => 'MySQLi',
    'DBPrefix' => '',
    'pConnect' => false,
    'DBDebug' => (ENVIRONMENT !== 'production'),
    'charset' => 'utf8',
    'DBCollate' => 'utf8_general_ci',
    'swapPre' => '',
    'encrypt' => false,
    'compress' => false,
    'strictOn' => false,
    'failover' => [],
    'port' => 3306,
];
```

### Step 4: Frontend Integration
```html
<!-- Add to your main page -->
<link rel="stylesheet" href="/assets/frontend/css/chatbot.css">

<!-- Chatbot HTML structure -->
<div id="chatbotContainer" class="chatbot-container">
    <!-- Chat button -->
    <div id="chatButton" class="chat-button">
        <i class="fas fa-comments"></i>
        <span id="notificationBadge" class="notification-badge">0</span>
    </div>
    
    <!-- Chat window -->
    <div id="chatWindow" class="chat-window" style="display: none;">
        <!-- Chat header -->
        <div class="chat-header">
            <h3>Customer Support</h3>
            <button id="minimizeBtn" class="minimize-btn">−</button>
            <button id="closeBtn" class="close-btn">×</button>
        </div>
        
        <!-- Chat messages -->
        <div id="chatMessages" class="chat-messages"></div>
        
        <!-- Chat input -->
        <div class="chat-input-container">
            <input type="text" id="chatInput" placeholder="Type your message...">
            <button id="sendBtn" class="send-btn">Send</button>
        </div>
    </div>
</div>

<!-- Load chatbot script -->
<script src="/assets/frontend/js/chatbot.js"></script>
<script>
    // Initialize chatbot
    const chatbot = new ChatbotWidget();
</script>
```

---

## 🧪 Testing Guide

### Test Scenarios

#### 1. Basic Functionality
```bash
# Test 1: Basic chat
1. Open website
2. Click chat button
3. Type "Hello"
4. Verify bot responds

# Test 2: Product search
1. Type "headphones"
2. Verify product cards appear
3. Click on product
4. Verify redirect to product page
```

#### 2. Multi-User Testing
```bash
# Test 3: Multiple browsers
1. Open Chrome - chat about "Nike shoes"
2. Open Firefox - chat about "headphones"
3. Verify separate conversations
4. Close browsers and reopen
5. Verify chat history persists
```

#### 3. Session Management
```bash
# Test 4: Session persistence
1. Chat in one browser
2. Close browser completely
3. Reopen and visit site
4. Verify "Welcome back!" message
5. Verify previous chat history loaded
```

#### 4. Error Handling
```bash
# Test 5: Network errors
1. Disconnect internet
2. Try to send message
3. Verify graceful error handling
4. Reconnect internet
5. Verify normal operation resumes
```

### Debug Tools

#### Console Logging
```javascript
// Enable debug logging
console.log('Session ID:', this.sessionId);
console.log('User Fingerprint:', this.userFingerprint);
console.log('Available products:', this.products.length);
console.log('Available Q&A:', this.qa.length);
```

#### Database Queries
```sql
-- Check sessions
SELECT * FROM chatbot_sessions ORDER BY started_at DESC LIMIT 10;

-- Check messages
SELECT * FROM chatbot_messages ORDER BY created_at DESC LIMIT 20;

-- Check user activity
SELECT 
    session_id,
    user_fingerprint,
    message_count,
    started_at,
    last_activity
FROM chatbot_sessions 
ORDER BY last_activity DESC;
```

---

## 🔧 Troubleshooting

### Common Issues

#### 1. Chatbot Not Loading
**Symptoms**: Chatbot button not visible
**Solutions**:
```bash
# Check file paths
ls public/assets/frontend/js/chatbot.js
ls public/assets/frontend/css/chatbot.css

# Check browser console for errors
F12 → Console tab

# Verify JavaScript loading
<script src="/assets/frontend/js/chatbot.js"></script>
```

#### 2. Database Connection Errors
**Symptoms**: 500 errors on API calls
**Solutions**:
```bash
# Check database connection
mysql -u root -p rmbstore

# Verify tables exist
SHOW TABLES LIKE 'chatbot_%';

# Check database configuration
app/Config/Database.php
```

#### 3. Session Not Saving
**Symptoms**: Chat history not persisting
**Solutions**:
```bash
# Check session table
SELECT * FROM chatbot_sessions;

# Verify API endpoints
curl -X POST http://localhost:8080/chatbot/saveSession

# Check browser console for errors
```

#### 4. Product Search Not Working
**Symptoms**: No products found
**Solutions**:
```bash
# Check products table
SELECT * FROM chatbot_products WHERE status = 'active';

# Verify API response
curl http://localhost:8080/chatbot/getProducts

# Check JavaScript console
console.log('Products:', this.products);
```

#### 5. Messages Disappearing
**Symptoms**: Messages vanish after sending
**Solutions**:
```bash
# Check message monitoring
# Remove problematic MutationObserver code

# Verify addMessage function
# Ensure proper DOM manipulation

# Check for JavaScript errors
F12 → Console tab
```

### Performance Issues

#### 1. Slow Response Times
**Solutions**:
```sql
-- Add database indexes
CREATE INDEX idx_messages_session ON chatbot_messages (session_id, created_at);
CREATE INDEX idx_products_search ON chatbot_products (name, category, status);
CREATE INDEX idx_qa_search ON chatbot_qa (question, keywords, status);
```

#### 2. Memory Leaks
**Solutions**:
```javascript
// Clean up event listeners
window.removeEventListener('beforeunload', this.handleBeforeUnload);

// Clear intervals
clearInterval(this.messageMonitor);

// Remove DOM references
this.chatMessages = null;
```

---

## 🔄 Maintenance & Updates

### Regular Maintenance

#### 1. Database Cleanup
```sql
-- Clean old sessions (older than 30 days)
DELETE FROM chatbot_sessions 
WHERE last_activity < DATE_SUB(NOW(), INTERVAL 30 DAY);

-- Clean old messages (older than 90 days)
DELETE FROM chatbot_messages 
WHERE created_at < DATE_SUB(NOW(), INTERVAL 90 DAY);

-- Optimize tables
OPTIMIZE TABLE chatbot_sessions;
OPTIMIZE TABLE chatbot_messages;
```

#### 2. Log Monitoring
```php
// Enable logging in production
log_message('info', 'Chatbot session created: ' . $sessionId);
log_message('error', 'Chatbot error: ' . $error->getMessage());
```

#### 3. Performance Monitoring
```sql
-- Monitor table sizes
SELECT 
    table_name,
    ROUND(((data_length + index_length) / 1024 / 1024), 2) AS 'Size (MB)'
FROM information_schema.tables 
WHERE table_schema = 'rmbstore' 
AND table_name LIKE 'chatbot_%';

-- Monitor active sessions
SELECT COUNT(*) as active_sessions 
FROM chatbot_sessions 
WHERE last_activity > DATE_SUB(NOW(), INTERVAL 1 HOUR);
```

### Updates & Enhancements

#### 1. Adding New Features
```javascript
// Example: Add typing indicators
showTypingIndicator() {
    this.typingIndicator.style.display = 'block';
}

hideTypingIndicator() {
    this.typingIndicator.style.display = 'none';
}
```

#### 2. Database Schema Updates
```sql
-- Example: Add new field
ALTER TABLE chatbot_messages 
ADD COLUMN message_sentiment ENUM('positive', 'negative', 'neutral') DEFAULT 'neutral';

-- Example: Add new table
CREATE TABLE chatbot_analytics (
    id INT AUTO_INCREMENT PRIMARY KEY,
    session_id VARCHAR(255),
    event_type VARCHAR(50),
    event_data JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### 3. API Enhancements
```php
// Example: Add analytics endpoint
public function saveAnalytics()
{
    $sessionId = $this->request->getPost('sessionId');
    $eventType = $this->request->getPost('eventType');
    $eventData = $this->request->getPost('eventData');
    
    $data = [
        'session_id' => $sessionId,
        'event_type' => $eventType,
        'event_data' => json_encode($eventData),
        'created_at' => date('Y-m-d H:i:s')
    ];
    
    $this->db->table('chatbot_analytics')->insert($data);
    
    return $this->response->setJSON(['success' => true]);
}
```

---

## 📚 Additional Resources

### Code References
- [CodeIgniter 4 Documentation](https://codeigniter4.github.io/userguide/)
- [JavaScript ES6+ Guide](https://developer.mozilla.org/en-US/docs/Web/JavaScript)
- [MySQL Documentation](https://dev.mysql.com/doc/)

### Best Practices
- Always validate user input
- Use prepared statements for database queries
- Implement proper error handling
- Follow security best practices
- Test thoroughly before deployment

### Security Considerations
- Sanitize all user inputs
- Use HTTPS in production
- Implement rate limiting
- Regular security updates
- Monitor for suspicious activity

---

## 📞 Support

For technical support or questions about this implementation:

1. **Check the troubleshooting section** above
2. **Review the code comments** in the source files
3. **Test with the provided scenarios**
4. **Check browser console** for JavaScript errors
5. **Verify database connectivity** and table structure

---

**Documentation Version**: 1.0  
**Last Updated**: August 21, 2025  
**Compatible With**: CodeIgniter 4, PHP 8.0+, MySQL 8.0+  
**Author**: AI Assistant  
**Project**: RMB Store Multi-User Chatbot System
