-- Chatbot Database Setup for RMB Store
-- Run this SQL to create the necessary tables

-- Products table for chatbot search
CREATE TABLE IF NOT EXISTS `chatbot_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text,
  `category` varchar(100) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `stock` int(11) DEFAULT 0,
  `image` varchar(255),
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_category` (`category`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Q&A table for chatbot responses
CREATE TABLE IF NOT EXISTS `chatbot_qa` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question` text NOT NULL,
  `answer` text NOT NULL,
  `category` varchar(100) DEFAULT 'general',
  `keywords` text,
  `priority` int(11) DEFAULT 1,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_category` (`category`),
  KEY `idx_status` (`status`),
  KEY `idx_priority` (`priority`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Chat sessions table
CREATE TABLE IF NOT EXISTS `chatbot_sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `session_id` varchar(255) NOT NULL,
  `user_fingerprint` varchar(255) DEFAULT NULL,
  `user_ip` varchar(45),
  `user_agent` text,
  `started_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `last_activity` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `message_count` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_session_id` (`session_id`),
  KEY `idx_user_fingerprint` (`user_fingerprint`),
  KEY `idx_started_at` (`started_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Chat messages table
CREATE TABLE IF NOT EXISTS `chatbot_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `session_id` varchar(255) NOT NULL,
  `user_fingerprint` varchar(255) DEFAULT NULL,
  `sender` enum('user','bot','system') NOT NULL,
  `message` text NOT NULL,
  `message_type` enum('text','product_search','qa_response','ai_response') DEFAULT 'text',
  `metadata` json,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_session_id` (`session_id`),
  KEY `idx_user_fingerprint` (`user_fingerprint`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_sender` (`sender`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert sample products
INSERT INTO `chatbot_products` (`name`, `description`, `category`, `price`, `stock`, `image`, `status`) VALUES
('Nike Air Max 270', 'Comfortable running shoes with Air Max technology', 'Footwear', 129.99, 15, '/assets/frontend/images/product1.jpg', 'active'),
('Adidas Ultraboost 21', 'Premium running shoes with Boost technology', 'Footwear', 179.99, 8, '/assets/frontend/images/product1.jpg', 'active'),
('Puma RS-X', 'Retro-inspired sneakers with bold design', 'Footwear', 89.99, 12, '/assets/frontend/images/product1.jpg', 'active'),
('Nike Dri-FIT T-Shirt', 'Moisture-wicking athletic t-shirt', 'Apparel', 34.99, 25, '/assets/frontend/images/product1.jpg', 'active'),
('Adidas Track Jacket', 'Classic track jacket for sports and casual wear', 'Apparel', 59.99, 18, '/assets/frontend/images/product1.jpg', 'active'),
('Nike Basketball Shorts', 'Comfortable basketball shorts with Dri-FIT', 'Apparel', 44.99, 22, '/assets/frontend/images/product1.jpg', 'active'),
('Gym Bag Large', 'Spacious gym bag with multiple compartments', 'Accessories', 29.99, 30, '/assets/frontend/images/product1.jpg', 'active'),
('Water Bottle 32oz', 'Large capacity water bottle for workouts', 'Accessories', 19.99, 45, '/assets/frontend/images/product1.jpg', 'active'),
('Sony WH-1000XM4', 'Premium noise-cancelling wireless headphones', 'Electronics', 349.99, 10, '/assets/frontend/images/product1.jpg', 'active'),
('Bose QuietComfort 35 II', 'Comfortable wireless headphones with noise cancellation', 'Electronics', 299.99, 12, '/assets/frontend/images/product1.jpg', 'active'),
('Apple AirPods Pro', 'Active noise cancellation wireless earbuds', 'Electronics', 249.99, 20, '/assets/frontend/images/product1.jpg', 'active'),
('JBL Flip 5', 'Portable waterproof bluetooth speaker', 'Electronics', 119.99, 15, '/assets/frontend/images/product1.jpg', 'active');

-- Insert sample Q&A
INSERT INTO `chatbot_qa` (`question`, `answer`, `category`, `keywords`, `priority`) VALUES
('What are your business hours?', 'Our business hours are:\n🕐 Monday - Friday: 9:00 AM - 6:00 PM\n🕐 Saturday: 10:00 AM - 4:00 PM\n🕐 Sunday: Closed\n\nWe\'re here to serve you during these times!', 'business', 'hours,time,open,close,business', 1),
('Do you offer shipping?', 'Yes! We offer various shipping options:\n🚚 Standard: 3-5 business days\n🚚 Express: 1-2 business days\n🚚 Same day: Available for local orders\n\nShipping costs vary by location and speed.', 'shipping', 'shipping,delivery,ship,deliver', 1),
('What is your return policy?', 'We have a 30-day return policy for most items. Products must be in original condition with tags attached. For returns, please contact our customer service team.', 'returns', 'return,refund,exchange,policy', 1),
('Do you have Nike shoes?', 'Yes! We carry a wide selection of Nike shoes including running shoes, basketball shoes, and casual sneakers. You can search for specific models or ask about categories.', 'products', 'nike,shoes,footwear,available', 1),
('How can I contact customer service?', 'You can reach us through multiple channels:\n📧 Email: info@rmbstore.com\n📞 Phone: +1 (555) 123-4567\n💬 Live chat: Right here!\n\nWhat\'s the best way to help you?', 'contact', 'contact,phone,email,support,help', 1),
('Are your products authentic?', 'Absolutely! All our products are 100% authentic and sourced directly from authorized manufacturers and distributors. We guarantee the authenticity of every item.', 'quality', 'authentic,real,genuine,quality', 1),
('Do you have size guides?', 'Yes! We provide detailed size guides for all our products. You can find size charts on individual product pages or ask me about specific sizing information.', 'sizing', 'size,guide,chart,measurement', 2),
('Can I get a discount?', 'We regularly offer discounts and promotions! Check our website for current deals, sign up for our newsletter, or ask about any ongoing promotions.', 'pricing', 'discount,promotion,deal,sale', 2),
('Do you sell headphones?', 'Yes! We have a great selection of headphones including Sony, Bose, and Apple AirPods. We carry both wired and wireless options with noise cancellation features.', 'products', 'headphones,earbuds,audio,sony,bose,apple', 1);

-- Create indexes for better performance
CREATE INDEX `idx_products_search` ON `chatbot_products` (`name`, `category`, `status`);
CREATE INDEX `idx_qa_search` ON `chatbot_qa` (`question`, `keywords`, `status`);
CREATE INDEX `idx_messages_session` ON `chatbot_messages` (`session_id`, `created_at`);
